import flet as ft
from muebles.conexion import ConexionDB
from muebles.config import THEME
from muebles.components import ModernTextField, ModernButton, create_snackbar
from muebles.utils import hash_password, verify_password

class InicioSesionView(ft.Container):
    """
    Pantalla de inicio de sesión completamente rediseñada
    Diseño moderno, limpio y responsivo
    """
    def __init__(self, page: ft.Page, on_login_success, *, app_title: str = "Sistema de Venta de Muebles", accent_color: str = None):
        self.accent_color = accent_color or THEME["primary"]
        super().__init__(expand=True, bgcolor=THEME["bg_primary"])
        
        self.page = page
        self.on_login_success = on_login_success
        self.conexion = ConexionDB()
        self.app_title = app_title

        # Campos de entrada modernos
        self.input_usuario = ModernTextField(
            label="Usuario",
            hint_text="Ingresa tu usuario",
            prefix_icon=ft.Icons.PERSON_OUTLINE,
            autofocus=True,
            on_submit=self._on_submit_field,
            width=400
        )
        
        self.input_contrasena = ModernTextField(
            label="Contraseña",
            hint_text="Ingresa tu contraseña",
            password=True,
            prefix_icon=ft.Icons.LOCK_OUTLINE,
            on_submit=self._on_submit_field,
            width=400
        )

        self.chk_recordarme = ft.Checkbox(
            label="Recordarme",
            value=False,
            fill_color=self.accent_color
        )
        
        self.msg_error = ft.Text("", color=THEME["error"], size=13, visible=False)

        # Botón de login moderno
        self.btn_login = ModernButton(
            "Iniciar Sesión",
            style_type="primary",
            on_click=self.iniciar_sesion,
            width=400,
            height=50
        )
        
        self.btn_forgot = ft.TextButton(
            "¿Olvidaste tu contraseña?",
            on_click=self._forgot_password,
            style=ft.ButtonStyle(color=THEME["text_muted"])
        )

        # Logo y branding moderno
        logo_container = ft.Container(
            content=ft.Column(
                [
                    ft.Container(
                        content=ft.Icon(
                            ft.Icons.CHAIR,
                            size=64,
                            color=self.accent_color
                        ),
                        width=100,
                        height=100,
                        border_radius=THEME["radius_xl"],
                        bgcolor=self.accent_color + "1A",  # 10% opacidad en hex
                        alignment=ft.alignment.center
                    ),
                    ft.Container(height=THEME["spacing_lg"]),
                    ft.Text(
                        self.app_title,
                        size=28,
                        weight=ft.FontWeight.BOLD,
                        color=THEME["text_primary"]
                    ),
                    ft.Text(
                        "Gestiona tu negocio de forma eficiente",
                        size=14,
                        color=THEME["text_muted"],
                        text_align=ft.TextAlign.CENTER
                    )
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=THEME["spacing_sm"]
            ),
            alignment=ft.alignment.center,
            padding=ft.padding.all(THEME["spacing_xl"])
        )

        # Formulario de login
        form_container = ft.Container(
            content=ft.Column(
                [
                    ft.Text(
                        "Bienvenido",
                        size=32,
                        weight=ft.FontWeight.BOLD,
                        color=THEME["text_primary"]
                    ),
                    ft.Text(
                        "Inicia sesión para continuar",
                        size=14,
                        color=THEME["text_muted"]
                    ),
                    ft.Container(height=THEME["spacing_xl"]),
                    self.input_usuario,
                    ft.Container(height=THEME["spacing_md"]),
                    self.input_contrasena,
                    ft.Container(height=THEME["spacing_sm"]),
                    ft.Row(
                        [
                            self.chk_recordarme,
                            ft.Container(expand=True),
                            self.btn_forgot
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                    ),
                    self.msg_error,
                    ft.Container(height=THEME["spacing_md"]),
                    self.btn_login
                ],
                spacing=0,
                width=400
            ),
            padding=ft.padding.all(THEME["spacing_xl"]),
            bgcolor=THEME["bg_card"],
            border_radius=THEME["radius_xl"],
            border=ft.border.all(1, THEME["border"]),
            shadow=ft.BoxShadow(
                spread_radius=0,
                blur_radius=20,
                color="#80000000",  # 50% opacidad negro
                offset=ft.Offset(0, 4)
            )
        )

        # Layout responsivo
        self.content = ft.ResponsiveRow(
            [
                ft.Container(
                    content=logo_container,
                    col={"sm": 0, "md": 6},
                    expand=True,
                    alignment=ft.alignment.center,
                    padding=ft.padding.all(THEME["spacing_xl"])
                ),
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Container(expand=True),
                            form_container,
                            ft.Container(expand=True)
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        expand=True
                    ),
                    col={"sm": 12, "md": 6},
                    padding=ft.padding.all(THEME["spacing_xl"]),
                    alignment=ft.alignment.center
                )
            ],
            expand=True,
            spacing=0
        )

    def _on_submit_field(self, e):
        self.iniciar_sesion(e)

    def _forgot_password(self, e):
        dlg = ft.AlertDialog(
            modal=True,
            title=ft.Text("Recuperación de contraseña", color=THEME["text_primary"]),
            content=ft.Text(
                "Contacta al administrador del sistema para restablecer tu contraseña.",
                color=THEME["text_secondary"]
            ),
            bgcolor=THEME["bg_card"],
            actions=[
                ft.TextButton(
                    "Cerrar",
                    on_click=lambda ev: self._close_dialog(),
                    style=ft.ButtonStyle(color=THEME["primary"])
                )
            ]
        )
        self.page.dialog = dlg
        dlg.open = True
        self.page.update()

    def _close_dialog(self):
        if self.page.dialog:
            self.page.dialog.open = False
            self.page.update()

    def iniciar_sesion(self, e=None):
        username = (self.input_usuario.value or "").strip()
        password = (self.input_contrasena.value or "").strip()

        if not username or not password:
            self._show_error("Debes ingresar usuario y contraseña.")
            return

        self.btn_login.disabled = True
        self.btn_login.text = "Verificando..."
        self.msg_error.visible = False
        self.page.update()

        try:
            conn = self.conexion.conectar()
            if conn is None:
                self._show_error("No se pudo conectar a la base de datos.")
                return

            cur = conn.cursor()
            cur.execute(
                "SELECT id_usuario, nombre_usuario, usuario, contrasena, rol FROM usuarios WHERE usuario=%s LIMIT 1",
                (username,)
            )
            row = cur.fetchone()
            
            if not row:
                self._show_error("Usuario no encontrado.")
                return

            db_pass = row[3]
            if not (password == db_pass or verify_password(password, db_pass)):
                self._show_error("Contraseña incorrecta.")
                return

            user = {
                "id_usuario": row[0],
                "nombre_usuario": row[1],
                "usuario": row[2],
                "rol": row[4]
            }

            # Snackbar de éxito compatible con cualquier versión
            snackbar = ft.SnackBar(
                ft.Text(f"Bienvenido {user['nombre_usuario'] or user['usuario']}"),
                bgcolor=self.accent_color,
                open=True
            )
            self.page.snack_bar = snackbar
            self.page.update()

            try:
                self.on_login_success(user)
            except TypeError:
                self.on_login_success()
            except Exception as ex:
                self._show_error(f"Error al iniciar sesión: {ex}")

        except Exception as ex:
            self._show_error(f"Error de autenticación: {ex}")
        finally:
            self.btn_login.disabled = False
            self.btn_login.text = "Iniciar Sesión"
            self.page.update()
            try:
                if 'conn' in locals() and conn:
                    self.conexion.cerrar(conn)
            except:
                pass

    def _show_error(self, message: str):
        self.msg_error.value = message
        self.msg_error.visible = True
        self.page.update()
        # Snackbar de error
        snackbar = ft.SnackBar(
            ft.Text(message),
            bgcolor=THEME["error"],
            open=True
        )
        self.page.snack_bar = snackbar
        self.page.update()
