import flet as ft
from inicio_Sesion import InicioSesionView
from dashboard_view import DashboardView

def main(page: ft.Page):
    ACCENT = "#7C3AED"   # acento violeta brillante sobre fondo oscuro
    BG = "#071124"       # fondo global oscuro

    page.title = "Sistema de Venta de Muebles"
    page.window_width = 1320
    page.window_height = 820
    try:
        page.bgcolor = BG
    except Exception:
        try:
            page.window_bgcolor = BG
        except Exception:
            pass

    def cambiar_vista(vista_control):
        page.clean()
        if vista_control is not None:
            page.add(vista_control)
        try:
            page.update()
        except Exception:
            pass

    def login_exitoso(user=None):
        dashboard = DashboardView(page, cambiar_vista, user=user, accent_color=ACCENT)
        cambiar_vista(dashboard)

    # iniciar en pantalla de login con tema oscuro
    login_view = InicioSesionView(page, on_login_success=login_exitoso, accent_color=ACCENT)
    cambiar_vista(login_view)

if __name__ == "__main__":
    ft.app(target=main)