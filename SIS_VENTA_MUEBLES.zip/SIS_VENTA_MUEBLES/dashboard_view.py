import flet as ft
from muebles.clientes_view import ClientesView
from muebles.productos_view import ProductosView
from muebles.proveedores_view import ProveedoresView
from muebles.usuarios_view import UsuariosView
from muebles.ventas_view import VentasView
from muebles.detalle_venta_view import DetalleVentaView
from muebles.categorias_view import CategoriasView
from muebles.compras_view import ComprasView
from muebles.detalle_compra_view import DetalleCompraView
from muebles.config import THEME
from muebles.components import ModernCard, ModernButton, create_stat_card, create_snackbar, color_with_opacity

class DashboardView(ft.Container):
    """
    Dashboard completamente rediseñado
    Diseño moderno, responsivo y con mejor UX
    """
    def __init__(self, page, cambiar_vista, user=None, *, accent_color: str = None):
        self.accent_color = accent_color or THEME["primary"]
        super().__init__(expand=True, bgcolor=THEME["bg_primary"])
        
        self.page = page
        self.cambiar_vista = cambiar_vista
        self.user = user or {}

        # Módulos del sistema con iconos y colores
        self.modules = [
            {
                "name": "Clientes",
                "description": "Gestiona tu base de clientes",
                "icon": ft.Icons.PEOPLE,
                "color": "#3B82F6",
                "view": ClientesView
            },
            {
                "name": "Productos",
                "description": "Control de inventario",
                "icon": ft.Icons.INVENTORY_2,
                "color": "#10B981",
                "view": ProductosView
            },
            {
                "name": "Proveedores",
                "description": "Gestión de proveedores",
                "icon": ft.Icons.LOCAL_SHIPPING,
                "color": "#F59E0B",
                "view": ProveedoresView
            },
            {
                "name": "Usuarios",
                "description": "Administración de usuarios",
                "icon": ft.Icons.SUPERVISOR_ACCOUNT,
                "color": "#8B5CF6",
                "view": UsuariosView
            },
            {
                "name": "Ventas",
                "description": "Registro de ventas",
                "icon": ft.Icons.PAYMENT,
                "color": "#EF4444",
                "view": VentasView
            },
            {
                "name": "Detalle Venta",
                "description": "Detalles de ventas",
                "icon": ft.Icons.RECEIPT_LONG,
                "color": "#EC4899",
                "view": DetalleVentaView
            },
            {
                "name": "Categorías",
                "description": "Organiza por categorías",
                "icon": ft.Icons.LABEL,
                "color": "#06B6D4",
                "view": CategoriasView
            },
            {
                "name": "Compras",
                "description": "Registro de compras",
                "icon": ft.Icons.SHOPPING_CART,
                "color": "#14B8A6",
                "view": ComprasView
            },
            {
                "name": "Detalle Compra",
                "description": "Detalles de compras",
                "icon": ft.Icons.INVENTORY,
                "color": "#F97316",
                "view": DetalleCompraView
            },
        ]

        # Header moderno
        header = self._build_header()
        
        # Grid de módulos responsivo
        modules_grid = self._build_modules_grid()

        # Layout principal
        self.content = ft.Column(
            [
                header,
                ft.Container(
                    content=modules_grid,
                    expand=True,
                    padding=ft.padding.all(THEME["spacing_lg"])
                )
            ],
            spacing=0,
            expand=True
        )

    def _build_header(self):
        """Construye el header del dashboard"""
        avatar = ft.CircleAvatar(
            content=ft.Text(
                (self.user.get("usuario") or "U")[0].upper(),
                color="white",
                size=16,
                weight=ft.FontWeight.BOLD
            ),
            radius=20,
            bgcolor=self.accent_color
        )

        return ft.Container(
            content=ft.Row(
                [
                    ft.Row(
                        [
                            ft.Icon(ft.Icons.DASHBOARD, color=self.accent_color, size=28),
                            ft.Container(width=THEME["spacing_md"]),
                            ft.Column(
                                [
                                    ft.Text(
                                        "Panel de Control",
                                        size=24,
                                        weight=ft.FontWeight.BOLD,
                                        color=THEME["text_primary"]
                                    ),
                                    ft.Text(
                                        f"Bienvenido, {self.user.get('nombre_usuario', self.user.get('usuario', 'Usuario'))}",
                                        size=12,
                                        color=THEME["text_muted"]
                                    )
                                ],
                                spacing=0
                            )
                        ],
                        alignment=ft.MainAxisAlignment.START
                    ),
                    ft.Container(expand=True),
                    ModernButton(
                        "Cerrar Sesión",
                        style_type="danger",
                        on_click=lambda e: self._logout(),
                        height=40
                    )
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                vertical_alignment=ft.CrossAxisAlignment.CENTER
            ),
            padding=ft.padding.symmetric(
                horizontal=THEME["spacing_xl"],
                vertical=THEME["spacing_lg"]
            ),
            bgcolor=THEME["bg_card"],
            border=ft.border.only(
                bottom=ft.BorderSide(1, THEME["border"])
            )
        )

    def _build_modules_grid(self):
        """Construye el grid de módulos responsivo"""
        cards = []
        
        for module in self.modules:
            card = self._create_module_card(module)
            cards.append(card)

        # Grid responsivo: 1 columna en móvil, 2 en tablet, 3 en desktop
        return ft.ResponsiveRow(
            [
                ft.Container(
                    content=card,
                    col={"sm": 12, "md": 6, "lg": 4},
                    padding=ft.padding.all(THEME["spacing_md"])
                )
                for card in cards
            ],
            spacing=THEME["spacing_md"]
        )

    def _create_module_card(self, module):
        """Crea una tarjeta de módulo moderna"""
        return ModernCard(
            content=ft.Column(
                [
                    ft.Container(
                        content=ft.Icon(
                            module["icon"],
                            size=48,
                            color=module["color"]
                        ),
                        width=80,
                        height=80,
                        border_radius=THEME["radius_lg"],
                        bgcolor=color_with_opacity(module["color"], 0.1),
                        alignment=ft.alignment.center,
                        margin=ft.margin.only(bottom=THEME["spacing_md"])
                    ),
                    ft.Text(
                        module["name"],
                        size=20,
                        weight=ft.FontWeight.BOLD,
                        color=THEME["text_primary"]
                    ),
                    ft.Text(
                        module["description"],
                        size=13,
                        color=THEME["text_muted"],
                        text_align=ft.TextAlign.CENTER
                    ),
                    ft.Container(height=THEME["spacing_md"]),
                    ModernButton(
                        "Abrir",
                        style_type="primary",
                        on_click=lambda e, name=module["name"]: self.mostrar_tabla(name),
                        width=120,
                        height=36
                    )
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=THEME["spacing_sm"]
            ),
            width=300,
            height=280,
            on_click=lambda e, name=module["name"]: self.mostrar_tabla(name),
            data=module["name"]
        )

    def mostrar_tabla(self, nombre_tabla):
        """Navega a la vista correspondiente"""
        module = next((m for m in self.modules if m["name"] == nombre_tabla), None)
        
        if module:
            view_class = module["view"]
            view = view_class(
                self.page,
                volver_atras=lambda: self.cambiar_vista(
                    DashboardView(
                        self.page,
                        self.cambiar_vista,
                        user=self.user,
                        accent_color=self.accent_color
                    )
                )
            )
            self.cambiar_vista(view)
        else:
            snackbar = create_snackbar(
                f"Vista '{nombre_tabla}' no implementada",
                "warning"
            )
            self.page.show_snack_bar(snackbar)

    def _logout(self):
        """Cierra sesión y vuelve al login"""
        snackbar = create_snackbar("Sesión cerrada correctamente", "info")
        self.page.show_snack_bar(snackbar)
        self.cambiar_vista(None)