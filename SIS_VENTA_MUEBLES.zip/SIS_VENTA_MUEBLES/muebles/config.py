"""
Configuración centralizada del sistema
Tema, colores y constantes reutilizables
"""
import os
from typing import Dict

# Configuración de base de datos
DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "sistema_venta_muebles")
}

# Tema de colores moderno y responsivo
THEME = {
    # Colores principales
    "primary": "#6366F1",  # Indigo moderno
    "primary_dark": "#4F46E5",
    "primary_light": "#818CF8",
    
    # Colores secundarios
    "secondary": "#10B981",  # Verde esmeralda
    "accent": "#F59E0B",  # Ámbar
    
    # Colores de estado
    "success": "#10B981",
    "warning": "#F59E0B",
    "error": "#EF4444",
    "info": "#3B82F6",
    
    # Fondo
    "bg_primary": "#0F172A",  # Slate 900
    "bg_secondary": "#1E293B",  # Slate 800
    "bg_tertiary": "#334155",  # Slate 700
    "bg_card": "#1E293B",
    "bg_hover": "#334155",
    
    # Texto
    "text_primary": "#F1F5F9",  # Slate 100
    "text_secondary": "#CBD5E1",  # Slate 300
    "text_muted": "#94A3B8",  # Slate 400
    "text_disabled": "#64748B",  # Slate 500
    
    # Bordes y separadores
    "border": "#334155",
    "border_light": "#475569",
    "divider": "#334155",
    
    # Sombras
    "shadow_sm": "0 1px 2px 0 rgba(0, 0, 0, 0.3)",
    "shadow": "0 4px 6px -1px rgba(0, 0, 0, 0.3)",
    "shadow_lg": "0 10px 15px -3px rgba(0, 0, 0, 0.4)",
    
    # Espaciado
    "spacing_xs": 4,
    "spacing_sm": 8,
    "spacing_md": 16,
    "spacing_lg": 24,
    "spacing_xl": 32,
    
    # Bordes redondeados
    "radius_sm": 6,
    "radius_md": 12,
    "radius_lg": 16,
    "radius_xl": 24,
    
    # Breakpoints para responsividad
    "breakpoint_sm": 640,
    "breakpoint_md": 768,
    "breakpoint_lg": 1024,
    "breakpoint_xl": 1280,
}

# Estilos de botones reutilizables
BUTTON_STYLES = {
    "primary": {
        "bgcolor": THEME["primary"],
        "color": "white",
        "shape": "rounded",
        "radius": THEME["radius_md"]
    },
    "secondary": {
        "bgcolor": THEME["bg_tertiary"],
        "color": THEME["text_primary"],
        "shape": "rounded",
        "radius": THEME["radius_md"]
    },
    "success": {
        "bgcolor": THEME["success"],
        "color": "white",
        "shape": "rounded",
        "radius": THEME["radius_md"]
    },
    "danger": {
        "bgcolor": THEME["error"],
        "color": "white",
        "shape": "rounded",
        "radius": THEME["radius_md"]
    },
    "outline": {
        "bgcolor": "transparent",
        "color": THEME["primary"],
        "border": f"1px solid {THEME['primary']}",
        "shape": "rounded",
        "radius": THEME["radius_md"]
    }
}

