"""
Vista base reutilizable para todas las vistas CRUD
Diseño moderno, responsivo y consistente
"""
import flet as ft
from muebles.conexion import ConexionDB
from muebles.config import THEME
from muebles.components import (
    ModernCard, ModernButton, ModernTextField, ModernDataTable,
    create_snackbar, LoadingIndicator
)
from muebles.utils import validate_required, validate_number, format_currency, format_date

class BaseView(ft.Container):
    """
    Clase base para todas las vistas CRUD
    Proporciona funcionalidad común y diseño consistente
    """
    def __init__(self, page, volver_atras, title: str, icon: ft.Icons, color: str = None):
        super().__init__(expand=True, bgcolor=THEME["bg_primary"])
        
        self.page = page
        self.volver_atras = volver_atras
        self.conexion = ConexionDB()
        self.title = title
        self.icon = icon
        self.color = color or THEME["primary"]
        
        self.main_area = ft.Container(expand=True)
        self.tabla = None
        self.columns_meta = []
        self.pk_column = None
        
        # Layout principal
        self.content = ft.Column(
            [
                self._build_topbar(),
                ft.ResponsiveRow(
                    [
                        ft.Container(
                            content=self._build_sidebar(),
                            col={"sm": 12, "md": 3},
                            padding=ft.padding.all(THEME["spacing_md"])
                        ),
                        ft.Container(
                            content=self.main_area,
                            col={"sm": 12, "md": 9},
                            padding=ft.padding.all(THEME["spacing_md"]),
                            expand=True
                        )
                    ],
                    spacing=THEME["spacing_md"],
                    expand=True
                )
            ],
            spacing=0,
            expand=True
        )

    def _build_topbar(self):
        """Construye la barra superior"""
        return ft.Container(
            content=ft.Row(
                [
                    ModernButton(
                        "← Volver",
                        style_type="secondary",
                        on_click=lambda e: self.volver_atras(),
                        height=40
                    ),
                    ft.Container(width=THEME["spacing_md"]),
                    ft.Icon(self.icon, color=self.color, size=24),
                    ft.Container(width=THEME["spacing_sm"]),
                    ft.Column(
                        [
                            ft.Text(
                                self.title,
                                size=22,
                                weight=ft.FontWeight.BOLD,
                                color=THEME["text_primary"]
                            ),
                            ft.Text(
                                f"Gestión de {self.title.lower()}",
                                size=12,
                                color=THEME["text_muted"]
                            )
                        ],
                        spacing=0
                    ),
                    ft.Container(expand=True),
                    ft.Container(
                        content=ft.Row(
                            [
                                ModernButton(
                                    "➕ Nuevo",
                                    style_type="primary",
                                    on_click=lambda e: self.mostrar_formulario_agregar(),
                                    height=40
                                ),
                                ft.Container(width=THEME["spacing_sm"]),
                                ModernButton(
                                    "🔄 Refrescar",
                                    style_type="secondary",
                                    on_click=lambda e: self.cargar_datos(),
                                    height=40
                                )
                            ],
                            spacing=THEME["spacing_sm"]
                        )
                    )
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER
            ),
            padding=ft.padding.symmetric(
                horizontal=THEME["spacing_xl"],
                vertical=THEME["spacing_lg"]
            ),
            bgcolor=THEME["bg_card"],
            border=ft.border.only(
                bottom=ft.BorderSide(1, THEME["border"])
            )
        )

    def _build_sidebar(self):
        """Construye la barra lateral con acciones rápidas"""
        return ModernCard(
            content=ft.Column(
                [
                    ft.Text(
                        "Acciones Rápidas",
                        size=16,
                        weight=ft.FontWeight.BOLD,
                        color=THEME["text_primary"]
                    ),
                    ft.Divider(color=THEME["divider"], height=1),
                    ft.Container(height=THEME["spacing_md"]),
                    ModernButton(
                        "➕ Agregar",
                        style_type="primary",
                        on_click=lambda e: self.mostrar_formulario_agregar(),
                        width=200
                    ),
                    ft.Container(height=THEME["spacing_sm"]),
                    ModernButton(
                        "🔄 Refrescar",
                        style_type="secondary",
                        on_click=lambda e: self.cargar_datos(),
                        width=200
                    ),
                    ft.Container(expand=True),
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Text(
                                    "💡 Tip",
                                    size=12,
                                    weight=ft.FontWeight.BOLD,
                                    color=THEME["text_secondary"]
                                ),
                                ft.Text(
                                    "Usa los botones de acción en cada fila para editar o eliminar registros.",
                                    size=11,
                                    color=THEME["text_muted"]
                                )
                            ],
                            spacing=THEME["spacing_xs"]
                        ),
                        padding=ft.padding.all(THEME["spacing_md"]),
                        bgcolor=THEME["bg_secondary"],
                        border_radius=THEME["radius_md"]
                    )
                ],
                spacing=THEME["spacing_sm"]
            ),
            width=250
        )

    def cargar_datos(self):
        """Método abstracto - debe ser implementado por las subclases"""
        raise NotImplementedError("cargar_datos debe ser implementado")

    def mostrar_formulario_agregar(self):
        """Método abstracto - debe ser implementado por las subclases"""
        raise NotImplementedError("mostrar_formulario_agregar debe ser implementado")

    def mostrar_formulario_editar(self, id_registro):
        """Método abstracto - debe ser implementado por las subclases"""
        raise NotImplementedError("mostrar_formulario_editar debe ser implementado")

    def confirmar_eliminar(self, id_registro):
        """Muestra diálogo de confirmación para eliminar"""
        def eliminar(ev):
            conn = self.conexion.conectar()
            if conn is None:
                self._show_message("No hay conexión a la base de datos", "error")
                return
            
            try:
                cur = conn.cursor()
                cur.execute(
                    f"DELETE FROM {self.table_name} WHERE {self.pk_column}=%s",
                    (id_registro,)
                )
                conn.commit()
                self._show_message("Registro eliminado correctamente", "success")
                self.cargar_datos()
            except Exception as ex:
                self._show_message(f"Error al eliminar: {ex}", "error")
            finally:
                self.conexion.cerrar(conn)
            
            if self.page.dialog:
                self.page.dialog.open = False
                self.page.update()

        dlg = ft.AlertDialog(
            modal=True,
            title=ft.Text("Confirmar eliminación", color=THEME["text_primary"]),
            content=ft.Text(
                f"¿Estás seguro de eliminar este registro? Esta acción no se puede deshacer.",
                color=THEME["text_secondary"]
            ),
            bgcolor=THEME["bg_card"],
            actions=[
                ft.TextButton(
                    "Cancelar",
                    on_click=lambda e: self._close_dialog(),
                    style=ft.ButtonStyle(color=THEME["text_secondary"])
                ),
                ft.ElevatedButton(
                    "Eliminar",
                    on_click=eliminar,
                    style=ft.ButtonStyle(
                        bgcolor=THEME["error"],
                        color="white",
                        shape=ft.RoundedRectangleBorder(radius=THEME["radius_md"])
                    )
                )
            ]
        )
        self.page.dialog = dlg
        dlg.open = True
        self.page.update()

    def _close_dialog(self):
        """Cierra el diálogo actual"""
        if self.page.dialog:
            self.page.dialog.open = False
            self.page.update()

    def _show_message(self, message: str, type: str = "info"):
        """Muestra un mensaje al usuario"""
        snackbar = create_snackbar(message, type)
        self.page.show_snack_bar(snackbar)

    def _show_loading(self):
        """Muestra indicador de carga"""
        self.main_area.content = LoadingIndicator()
        self.page.update()

    def switch_view(self, widget):
        """Cambia la vista del área principal"""
        self.main_area.content = widget
        self.page.update()

