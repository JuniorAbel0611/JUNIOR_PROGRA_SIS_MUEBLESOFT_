import flet as ft
from muebles.conexion import ConexionDB
import mysql.connector

class VentasView(ft.Container):
    """
    Ventas view - UI adaptada al tema y text_style aplicado a campos.
    CRUD sin cambios en la lógica.
    """
    def __init__(self, page, volver_atras):
        super().__init__(expand=True, bgcolor="#0B1620")
        self.page = page
        self.volver_atras = volver_atras
        self.conexion = ConexionDB()

        self.ACCENT = "#0EA5A4"
        self.SURFACE = "#09121A"
        self.PAPER = "#07121A"
        self.TEXT_PRIMARY = "#E6F6F5"
        self.TEXT_MUTED = "#98B7B5"
        self.SEPARATOR = "#123239"
        self.btn_primary = ft.ButtonStyle(bgcolor=self.ACCENT, color="white", shape=ft.RoundedRectangleBorder(radius=8))
        self.btn_secondary = ft.ButtonStyle(bgcolor="#0D2A30", color=self.TEXT_PRIMARY, shape=ft.RoundedRectangleBorder(radius=8))

        self.titulo = ft.Text("💳 Gestión de Ventas", size=22, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY)
        self.tabla = ft.DataTable(columns=[ft.DataColumn(ft.Text("ID", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Cliente ID", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Usuario ID", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Fecha", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Total", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Acciones", color=self.TEXT_PRIMARY))], rows=[])
        self.btn_volver = ft.ElevatedButton("⬅️ Volver", on_click=lambda e: self.volver_atras(), style=self.btn_secondary)
        self.btn_agregar = ft.ElevatedButton("➕ Agregar", on_click=self.mostrar_formulario_agregar, style=self.btn_primary)

        self.main_area = ft.Container(expand=True)
        self.content = ft.Column([self._build_topbar(), ft.Row([self._build_left_panel(), ft.Container(self.main_area, expand=True, padding=ft.padding.all(18))], spacing=12, expand=True)], expand=True)

        self.cargar_ventas()

    def _build_topbar(self):
        return ft.Container(content=ft.Row([self.btn_volver, ft.Container(width=12), ft.Text("Ventas — Panel", color=self.TEXT_PRIMARY, size=20, weight=ft.FontWeight.BOLD), ft.Container(expand=True)]), padding=ft.padding.symmetric(vertical=12, horizontal=18), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)

    def _build_left_panel(self):
        btn_add = ft.ElevatedButton("➕ Nueva venta", on_click=lambda e: self.mostrar_formulario_agregar(), style=self.btn_primary, width=180)
        btn_refresh = ft.ElevatedButton("🔁 Refrescar", on_click=lambda e: self.cargar_ventas(), style=self.btn_secondary, width=180)
        panel = ft.Container(content=ft.Column([ft.Text("Acciones rápidas", weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY), ft.Text("Crear y refrescar ventas", size=12, color=self.TEXT_MUTED), ft.Divider(color=self.SEPARATOR), btn_add, ft.Container(height=8), btn_refresh, ft.Container(expand=True)], spacing=10), padding=ft.padding.all(14), bgcolor=self.PAPER, border=ft.border.all(1, self.SEPARATOR), border_radius=8, width=260)
        return panel

    def switch_view(self, widget):
        self.main_area.content = widget
        try:
            self.page.update()
        except Exception:
            pass

    def cargar_ventas(self):
        print(">> cargar_ventas() llamado")
        self.tabla.rows.clear()
        conn = self.conexion.conectar()
        try:
            if conn is None:
                print("❌ No hay conexión")
                return
            cur = conn.cursor()
            cur.execute("SELECT id_venta, id_cliente, id_usuario, fecha_venta, total FROM ventas")
            filas = cur.fetchall()
            for f in filas:
                id_v = f[0]
                btn_editar = ft.IconButton(icon=ft.Icons.EDIT, tooltip="Editar", on_click=lambda e, _id=id_v: self.mostrar_formulario_editar_id(_id), icon_color=self.ACCENT)
                btn_borrar = ft.IconButton(icon=ft.Icons.DELETE, tooltip="Eliminar", icon_color="#EF4444", on_click=lambda e, _id=id_v: self.confirmar_eliminar_id(_id))
                self.tabla.rows.append(ft.DataRow(cells=[ft.DataCell(ft.Text(str(f[0]), color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(str(f[1]) if f[1] is not None else "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(str(f[2]) if f[2] is not None else "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(str(f[3]) if f[3] is not None else "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(str(f[4]) if f[4] is not None else "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Row([btn_editar, btn_borrar], spacing=6))]))
            print(f">> {len(filas)} ventas añadidas")
        except Exception as ex:
            print(f"❌ Error al cargar ventas: {ex}")
        finally:
            self.conexion.cerrar(conn)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[ft.Container(content=ft.Column([self.titulo, ft.Divider(color=self.SEPARATOR), self.tabla], spacing=10), padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)])
        try:
            self.page.update()
        except Exception:
            pass

    def mostrar_formulario_agregar(self, e=None):
        input_text_style = ft.TextStyle(color="white")
        label_style = ft.TextStyle(color=self.TEXT_MUTED)

        id_field = ft.TextField(label="ID (opcional)", hint_text="Dejar vacío para autoincrement", width=200, text_style=input_text_style, label_style=label_style)
        id_cliente = ft.TextField(label="ID Cliente", text_style=input_text_style, label_style=label_style)
        id_usuario = ft.TextField(label="ID Usuario", text_style=input_text_style, label_style=label_style)
        fecha = ft.TextField(label="Fecha (YYYY-MM-DD HH:MM:SS)", text_style=input_text_style, label_style=label_style)
        total = ft.TextField(label="Total", text_style=input_text_style, label_style=label_style)

        def guardar(ev):
            id_val = (id_field.value or "").strip()
            conn = self.conexion.conectar()
            if conn is None:
                print("❌ No hay conexión al guardar venta")
                return
            try:
                cur = conn.cursor()
                if id_val != "":
                    try:
                        id_int = int(id_val)
                    except ValueError:
                        print("❌ ID inválido")
                        return
                    cur.execute("INSERT INTO ventas (id_venta, id_cliente, id_usuario, fecha_venta, total) VALUES (%s, %s, %s, %s, %s)", (id_int, id_cliente.value, id_usuario.value, fecha.value, total.value))
                else:
                    cur.execute("INSERT INTO ventas (id_cliente, id_usuario, fecha_venta, total) VALUES (%s, %s, %s, %s)", (id_cliente.value, id_usuario.value, fecha.value, total.value))
                conn.commit()
                print(">> Venta insertada correctamente")
                self._build_table_view()
                self.cargar_ventas()
            except mysql.connector.IntegrityError as ie:
                print(f"❌ Integridad DB: {ie}")
            except Exception as ex:
                print(f"❌ Error al agregar venta: {ex}")
            finally:
                self.conexion.cerrar(conn)

        form = ft.Container(content=ft.Column([ft.Text("➕ Nueva Venta", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY), ft.Divider(color=self.SEPARATOR), id_field, id_cliente, id_usuario, fecha, total, ft.Row([ft.ElevatedButton("Cancelar", on_click=lambda e: (self._build_table_view(), self.cargar_ventas()), style=self.btn_secondary), ft.ElevatedButton("Guardar", on_click=guardar, style=self.btn_primary)], spacing=12)], spacing=12), padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[form])
        try:
            self.page.update()
        except Exception:
            pass

    def mostrar_formulario_editar_id(self, id_venta):
        conn = self.conexion.conectar()
        if conn is None:
            print("❌ No hay conexión")
            return
        try:
            cur = conn.cursor()
            cur.execute("SELECT id_cliente, id_usuario, fecha_venta, total FROM ventas WHERE id_venta = %s", (id_venta,))
            datos = cur.fetchone()
            if not datos:
                print("❌ Venta no encontrada")
                self._build_table_view()
                return
            input_text_style = ft.TextStyle(color="white")
            label_style = ft.TextStyle(color=self.TEXT_MUTED)
            id_cliente = ft.TextField(label="ID Cliente", value=str(datos[0]) if datos[0] is not None else "", text_style=input_text_style, label_style=label_style)
            id_usuario = ft.TextField(label="ID Usuario", value=str(datos[1]) if datos[1] is not None else "", text_style=input_text_style, label_style=label_style)
            fecha = ft.TextField(label="Fecha (YYYY-MM-DD HH:MM:SS)", value=str(datos[2]) if datos[2] is not None else "", text_style=input_text_style, label_style=label_style)
            total = ft.TextField(label="Total", value=str(datos[3]) if datos[3] is not None else "", text_style=input_text_style, label_style=label_style)
        except Exception as ex:
            print(f"❌ Error al cargar venta: {ex}")
            return
        finally:
            self.conexion.cerrar(conn)

        def guardar(ev):
            conn2 = self.conexion.conectar()
            if conn2 is None:
                print("❌ No hay conexión")
                return
            try:
                cur2 = conn2.cursor()
                cur2.execute("UPDATE ventas SET id_cliente=%s, id_usuario=%s, fecha_venta=%s, total=%s WHERE id_venta=%s", (id_cliente.value, id_usuario.value, fecha.value, total.value, id_venta))
                conn2.commit()
                print(">> Venta actualizada correctamente")
                self._build_table_view()
                self.cargar_ventas()
            except Exception as ex:
                print(f"❌ Error al editar venta: {ex}")
            finally:
                self.conexion.cerrar(conn2)

        form = ft.Container(content=ft.Column([ft.Text(f"✏️ Editar Venta (ID: {id_venta})", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY), ft.Divider(color=self.SEPARATOR), id_cliente, id_usuario, fecha, total, ft.Row([ft.ElevatedButton("Cancelar", on_click=lambda e: (self._build_table_view(), self.cargar_ventas()), style=self.btn_secondary), ft.ElevatedButton("Guardar", on_click=guardar, style=self.btn_primary)], spacing=12)], spacing=12), padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[form])
        try:
            self.page.update()
        except Exception:
            pass

    def confirmar_eliminar_id(self, id_venta):
        def eliminar(ev):
            conn = self.conexion.conectar()
            try:
                if conn is None:
                    print("❌ No hay conexión")
                    return
                cur = conn.cursor()
                cur.execute("DELETE FROM ventas WHERE id_venta = %s", (id_venta,))
                conn.commit()
                print(">> Venta eliminada correctamente")
                self._build_table_view()
                self.cargar_ventas()
            except Exception as ex:
                print(f"❌ Error al eliminar venta: {ex}")
            finally:
                self.conexion.cerrar(conn)
        confirm = ft.Container(content=ft.Column([ft.Text("⚠️ Confirmar eliminación", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY), ft.Text(f"¿Eliminar venta ID: {id_venta}?", color=self.TEXT_MUTED), ft.Row([ft.ElevatedButton("Cancelar", on_click=lambda e: (self._build_table_view(), self.cargar_ventas()), style=self.btn_secondary), ft.ElevatedButton("Eliminar", on_click=eliminar, style=ft.ButtonStyle(bgcolor="#EF4444", color="white"))], spacing=12)], spacing=12), padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[confirm])
        try:
            self.page.update()
        except Exception:
            pass