import flet as ft
from muebles.conexion import ConexionDB
import mysql.connector

class CategoriasView(ft.Container):
    """
    Categorías view - UI adaptada al tema oscuro; campos con text_style blanco.
    CRUD sin cambios.
    """
    def __init__(self, page, volver_atras):
        super().__init__(expand=True, bgcolor="#0B1620")
        self.page = page
        self.volver_atras = volver_atras
        self.conexion = ConexionDB()

        self.ACCENT = "#0EA5A4"
        self.SURFACE = "#09121A"
        self.PAPER = "#07121A"
        self.TEXT_PRIMARY = "#E6F6F5"
        self.TEXT_MUTED = "#98B7B5"
        self.SEPARATOR = "#123239"
        self.btn_primary = ft.ButtonStyle(bgcolor=self.ACCENT, color="white", shape=ft.RoundedRectangleBorder(radius=8))
        self.btn_secondary = ft.ButtonStyle(bgcolor="#0D2A30", color=self.TEXT_PRIMARY, shape=ft.RoundedRectangleBorder(radius=8))

        self.titulo = ft.Text("🏷️ Gestión de Categorías", size=22, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY)
        self.tabla = ft.DataTable(columns=[ft.DataColumn(ft.Text("ID", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Nombre", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Descripción", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Acciones", color=self.TEXT_PRIMARY))], rows=[])
        self.btn_volver = ft.ElevatedButton("⬅️ Volver", on_click=lambda e: self.volver_atras(), style=self.btn_secondary)
        self.btn_agregar = ft.ElevatedButton("➕ Agregar", on_click=self.mostrar_formulario_agregar, style=self.btn_primary)

        self.main_area = ft.Container(expand=True)
        self.content = ft.Column([self._build_topbar(), ft.Row([self._build_left_panel(), ft.Container(self.main_area, expand=True, padding=ft.padding.all(18))], spacing=12, expand=True)], expand=True)

        self.cargar_categorias()

    def _build_topbar(self):
        return ft.Container(content=ft.Row([self.btn_volver, ft.Container(width=12), ft.Text("Categorías — Panel", color=self.TEXT_PRIMARY, size=20, weight=ft.FontWeight.BOLD), ft.Container(expand=True)]), padding=ft.padding.symmetric(vertical=12, horizontal=18), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)

    def _build_left_panel(self):
        btn_add = ft.ElevatedButton("➕ Nueva categoría", on_click=lambda e: self.mostrar_formulario_agregar(), style=self.btn_primary, width=180)
        btn_refresh = ft.ElevatedButton("🔁 Refrescar", on_click=lambda e: self.cargar_categorias(), style=self.btn_secondary, width=180)
        panel = ft.Container(content=ft.Column([ft.Text("Acciones rápidas", weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY), ft.Text("Crear y refrescar categorías", size=12, color=self.TEXT_MUTED), ft.Divider(color=self.SEPARATOR), btn_add, ft.Container(height=8), btn_refresh, ft.Container(expand=True)], spacing=10), padding=ft.padding.all(14), bgcolor=self.PAPER, border=ft.border.all(1, self.SEPARATOR), border_radius=8, width=260)
        return panel

    def switch_view(self, widget):
        self.main_area.content = widget
        try:
            self.page.update()
        except Exception:
            pass

    def cargar_categorias(self):
        print(">> cargar_categorias() llamado")
        self.tabla.rows.clear()
        conn = self.conexion.conectar()
        try:
            if conn is None:
                print("❌ No hay conexión")
                return
            cur = conn.cursor()
            cur.execute("SELECT id_categoria, nombre_categoria, descripcion FROM categorias")
            filas = cur.fetchall()
            for r in filas:
                id_c = r[0]
                btn_editar = ft.IconButton(icon=ft.Icons.EDIT, tooltip="Editar", on_click=lambda e, _id=id_c: self.mostrar_formulario_editar_id(_id), icon_color=self.ACCENT)
                btn_borrar = ft.IconButton(icon=ft.Icons.DELETE, tooltip="Eliminar", icon_color="#EF4444", on_click=lambda e, _id=id_c: self.confirmar_eliminar_id(_id))
                self.tabla.rows.append(ft.DataRow(cells=[ft.DataCell(ft.Text(str(r[0]), color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(r[1] or "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(r[2] or "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Row([btn_editar, btn_borrar], spacing=6))]))
            print(f">> {len(filas)} categorias añadidas")
        except Exception as ex:
            print(f"❌ Error al cargar categorias: {ex}")
        finally:
            self.conexion.cerrar(conn)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[ft.Container(content=ft.Column([self.titulo, ft.Divider(color=self.SEPARATOR), self.tabla], spacing=10), padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)])
        try:
            self.page.update()
        except Exception:
            pass

    def mostrar_formulario_agregar(self, e=None):
        input_text_style = ft.TextStyle(color="white")
        label_style = ft.TextStyle(color=self.TEXT_MUTED)
        id_field = ft.TextField(label="ID (opcional)", hint_text="Dejar vacío para autoincrement", width=200, text_style=input_text_style, label_style=label_style)
        nombre = ft.TextField(label="Nombre", text_style=input_text_style, label_style=label_style)
        descripcion = ft.TextField(label="Descripción", text_style=input_text_style, label_style=label_style)

        def guardar(ev):
            id_val = (id_field.value or "").strip()
            conn = self.conexion.conectar()
            if conn is None:
                print("❌ No hay conexión")
                return
            try:
                cur = conn.cursor()
                if id_val != "":
                    try:
                        id_int = int(id_val)
                    except ValueError:
                        print("❌ ID inválido")
                        return
                    cur.execute("INSERT INTO categorias (id_categoria, nombre_categoria, descripcion) VALUES (%s, %s, %s)", (id_int, nombre.value, descripcion.value))
                else:
                    cur.execute("INSERT INTO categorias (nombre_categoria, descripcion) VALUES (%s, %s)", (nombre.value, descripcion.value))
                conn.commit()
                print(">> Categoría insertada correctamente")
                self._build_table_view()
                self.cargar_categorias()
            except mysql.connector.IntegrityError as ie:
                print(f"❌ Integridad DB: {ie}")
            except Exception as ex:
                print(f"❌ Error al agregar categoría: {ex}")
            finally:
                self.conexion.cerrar(conn)

        form = ft.Container(content=ft.Column([ft.Text("➕ Nueva Categoría", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY), ft.Divider(color=self.SEPARATOR), id_field, nombre, descripcion, ft.Row([ft.ElevatedButton("Cancelar", on_click=lambda e: (self._build_table_view(), self.cargar_categorias()), style=self.btn_secondary), ft.ElevatedButton("Guardar", on_click=guardar, style=self.btn_primary)], spacing=12)], spacing=12), padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[form])
        try:
            self.page.update()
        except Exception:
            pass