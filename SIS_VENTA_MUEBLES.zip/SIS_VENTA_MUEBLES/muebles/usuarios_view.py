import flet as ft
from muebles.conexion import ConexionDB
import mysql.connector

class UsuariosView(ft.Container):
    """
    Usuarios view - visual actualizado, CRUD sin cambios.
    """
    def __init__(self, page, volver_atras):
        super().__init__(expand=True, bgcolor="#0B1620")
        self.page = page
        self.volver_atras = volver_atras
        self.conexion = ConexionDB()

        self.ACCENT = "#0EA5A4"
        self.SURFACE = "#09121A"
        self.PAPER = "#07121A"
        self.TEXT_PRIMARY = "#E6F6F5"
        self.TEXT_MUTED = "#98B7B5"
        self.SEPARATOR = "#123239"
        self.btn_primary = ft.ButtonStyle(bgcolor=self.ACCENT, color="white", shape=ft.RoundedRectangleBorder(radius=8))
        self.btn_secondary = ft.ButtonStyle(bgcolor="#0D2A30", color=self.TEXT_PRIMARY, shape=ft.RoundedRectangleBorder(radius=8))

        self.titulo = ft.Text("👤 Gestión de Usuarios", size=22, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY)
        self.tabla = ft.DataTable(columns=[ft.DataColumn(ft.Text("ID", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Nombre", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Usuario", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Rol", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Acciones", color=self.TEXT_PRIMARY))], rows=[])
        self.btn_volver = ft.ElevatedButton("⬅️ Volver", on_click=lambda e: self.volver_atras(), style=self.btn_secondary)
        self.btn_agregar = ft.ElevatedButton("➕ Agregar", on_click=self.mostrar_formulario_agregar, style=self.btn_primary)

        self.main_area = ft.Container(expand=True)
        self.content = ft.Column([self._build_topbar(), ft.Row([self._build_left_panel(), ft.Container(self.main_area, expand=True, padding=ft.padding.all(18))], spacing=12, expand=True)], expand=True)

        self.cargar_usuarios()

    def _build_topbar(self):
        return ft.Container(content=ft.Row([self.btn_volver, ft.Container(width=12), ft.Text("Usuarios — Panel", color=self.TEXT_PRIMARY, size=20, weight=ft.FontWeight.BOLD), ft.Container(expand=True)]), padding=ft.padding.symmetric(vertical=12, horizontal=18), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)

    def _build_left_panel(self):
        btn_add = ft.ElevatedButton("➕ Nuevo usuario", on_click=lambda e: self.mostrar_formulario_agregar(), style=self.btn_primary, width=180)
        btn_refresh = ft.ElevatedButton("🔁 Refrescar", on_click=lambda e: self.cargar_usuarios(), style=self.btn_secondary, width=180)
        panel = ft.Container(content=ft.Column([ft.Text("Acciones rápidas", weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY), ft.Text("Crear y refrescar usuarios", size=12, color=self.TEXT_MUTED), ft.Divider(color=self.SEPARATOR), btn_add, ft.Container(height=8), btn_refresh, ft.Container(expand=True)], spacing=10), padding=ft.padding.all(14), bgcolor=self.PAPER, border=ft.border.all(1, self.SEPARATOR), border_radius=8, width=260)
        return panel

    def switch_view(self, widget):
        self.main_area.content = widget
        try:
            self.page.update()
        except Exception:
            pass

    def cargar_usuarios(self):
        print(">> cargar_usuarios() llamado")
        self.tabla.rows.clear()
        conn = self.conexion.conectar()
        try:
            if conn is None:
                print("❌ No hay conexión")
                return
            cur = conn.cursor()
            cur.execute("SELECT id_usuario, nombre_usuario, usuario, rol FROM usuarios")
            filas = cur.fetchall()
            for f in filas:
                id_u = f[0]
                btn_editar = ft.IconButton(icon=ft.Icons.EDIT, tooltip="Editar", on_click=lambda e, _id=id_u: self.mostrar_formulario_editar_id(_id), icon_color=self.ACCENT)
                btn_borrar = ft.IconButton(icon=ft.Icons.DELETE, tooltip="Eliminar", icon_color="#EF4444", on_click=lambda e, _id=id_u: self.confirmar_eliminar_id(_id))
                self.tabla.rows.append(ft.DataRow(cells=[ft.DataCell(ft.Text(str(f[0]), color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(f[1] or "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(f[2] or "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(str(f[3]) if f[3] is not None else "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Row([btn_editar, btn_borrar], spacing=6))]))
            print(f">> {len(filas)} usuarios añadidos")
        except Exception as ex:
            print(f"❌ Error al cargar usuarios: {ex}")
        finally:
            self.conexion.cerrar(conn)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[ft.Container(content=ft.Column([self.titulo, ft.Divider(color=self.SEPARATOR), self.tabla], spacing=10), padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)])
        try:
            self.page.update()
        except Exception:
            pass

    def mostrar_formulario_agregar(self, e=None):
        input_text_style = ft.TextStyle(color="white")
        label_style = ft.TextStyle(color=self.TEXT_MUTED)

        id_field = ft.TextField(label="ID (opcional)", hint_text="Dejar vacío para autoincrement", width=200, text_style=input_text_style, label_style=label_style)
        nombre = ft.TextField(label="Nombre", text_style=input_text_style, label_style=label_style)
        usuario = ft.TextField(label="Usuario", text_style=input_text_style, label_style=label_style)
        contrasena = ft.TextField(label="Contraseña", text_style=input_text_style, label_style=label_style)
        rol = ft.TextField(label="Rol (e.g., admin,user)", text_style=input_text_style, label_style=label_style)

        def guardar(ev):
            id_val = (id_field.value or "").strip()
            conn = self.conexion.conectar()
            if conn is None:
                print("❌ No hay conexión al guardar usuario")
                return
            try:
                cur = conn.cursor()
                if id_val != "":
                    try:
                        id_int = int(id_val)
                    except ValueError:
                        print("❌ ID inválido")
                        return
                    cur.execute("INSERT INTO usuarios (id_usuario, nombre_usuario, usuario, contrasena, rol) VALUES (%s, %s, %s, %s, %s)", (id_int, nombre.value, usuario.value, contrasena.value, rol.value))
                else:
                    cur.execute("INSERT INTO usuarios (nombre_usuario, usuario, contrasena, rol) VALUES (%s, %s, %s, %s)", (nombre.value, usuario.value, contrasena.value, rol.value))
                conn.commit()
                print(">> Usuario insertado correctamente")
                self.cargar_usuarios()
            except mysql.connector.IntegrityError as ie:
                print(f"❌ Integridad DB: {ie}")
            except Exception as ex:
                print(f"❌ Error al agregar usuario: {ex}")
            finally:
                self.conexion.cerrar(conn)

        form = ft.Container(content=ft.Column([ft.Text("➕ Nuevo Usuario", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY), ft.Divider(color=self.SEPARATOR), id_field, nombre, usuario, contrasena, rol, ft.Row([ft.ElevatedButton("Cancelar", width=160, on_click=lambda e: self.cargar_usuarios(), style=self.btn_secondary), ft.ElevatedButton("Guardar", width=160, on_click=guardar, style=self.btn_primary)], spacing=12)], spacing=12), padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[form])
        try:
            self.page.update()
        except Exception:
            pass

    def mostrar_formulario_editar_id(self, id_usuario):
        conn = self.conexion.conectar()
        try:
            if conn is None:
                print("❌ No hay conexión para editar usuario")
                return
            cur = conn.cursor()
            cur.execute("SELECT nombre_usuario, usuario, contrasena, rol FROM usuarios WHERE id_usuario = %s", (id_usuario,))
            datos = cur.fetchone()
            if not datos:
                print("❌ Usuario no encontrado")
                self.cargar_usuarios()
                return
            input_text_style = ft.TextStyle(color="white")
            label_style = ft.TextStyle(color=self.TEXT_MUTED)
            nombre = ft.TextField(label="Nombre", value=datos[0], text_style=input_text_style, label_style=label_style)
            usuario = ft.TextField(label="Usuario", value=datos[1], text_style=input_text_style, label_style=label_style)
            contrasena = ft.TextField(label="Contraseña", value=datos[2], text_style=input_text_style, label_style=label_style)
            rol = ft.TextField(label="Rol", value=datos[3], text_style=input_text_style, label_style=label_style)
        except Exception as ex:
            print(f"❌ Error al cargar usuario: {ex}")
            return
        finally:
            self.conexion.cerrar(conn)

        def guardar(ev):
            conn2 = self.conexion.conectar()
            try:
                if conn2 is None:
                    print("❌ No hay conexión al guardar edición")
                    return
                cur2 = conn2.cursor()
                cur2.execute("UPDATE usuarios SET nombre_usuario=%s, usuario=%s, contrasena=%s, rol=%s WHERE id_usuario=%s", (nombre.value, usuario.value, contrasena.value, rol.value, id_usuario))
                conn2.commit()
                print(">> Usuario actualizado correctamente")
                self.cargar_usuarios()
            except Exception as ex:
                print(f"❌ Error al editar usuario: {ex}")
            finally:
                self.conexion.cerrar(conn2)

        form = ft.Container(content=ft.Column([ft.Text(f"✏️ Editar Usuario (ID: {id_usuario})", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY), ft.Divider(color=self.SEPARATOR), nombre, usuario, contrasena, rol, ft.Row([ft.ElevatedButton("Cancelar", width=160, on_click=lambda e: self.cargar_usuarios(), style=self.btn_secondary), ft.ElevatedButton("Guardar", width=160, on_click=guardar, style=self.btn_primary)], spacing=12)], spacing=12), padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[form])
        try:
            self.page.update()
        except Exception:
            pass

    def confirmar_eliminar_id(self, id_usuario):
        def eliminar(ev):
            conn = self.conexion.conectar()
            try:
                if conn is None:
                    print("❌ No hay conexión al eliminar usuario")
                    return
                cur = conn.cursor()
                cur.execute("DELETE FROM usuarios WHERE id_usuario = %s", (id_usuario,))
                conn.commit()
                print(">> Usuario eliminado correctamente")
                self.cargar_usuarios()
            except Exception as ex:
                print(f"❌ Error al eliminar usuario: {ex}")
            finally:
                self.conexion.cerrar(conn)
        confirm = ft.Container(content=ft.Column([ft.Text("⚠️ Confirmar eliminación", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY), ft.Text(f"¿Eliminar usuario ID: {id_usuario}?", color=self.TEXT_MUTED), ft.Row([ft.ElevatedButton("Cancelar", on_click=lambda e: self.cargar_usuarios(), style=self.btn_secondary), ft.ElevatedButton("Eliminar", on_click=eliminar, style=ft.ButtonStyle(bgcolor="#EF4444", color="white"))], spacing=12)], spacing=12), padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[confirm])
        try:
            self.page.update()
        except Exception:
            pass