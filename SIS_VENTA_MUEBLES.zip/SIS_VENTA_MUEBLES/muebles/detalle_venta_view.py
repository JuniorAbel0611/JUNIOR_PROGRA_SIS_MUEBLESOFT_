import flet as ft
from muebles.conexion import ConexionDB
import mysql.connector

class DetalleVentaView(ft.Container):
    """
    Detalle de Ventas (tema oscuro).
    Diseño: incluye header con btn_volver y btn_agregar para que el CRUD esté accesible.
    Lógica CRUD sin cambios.
    """
    def __init__(self, page, volver_atras):
        super().__init__(expand=True, bgcolor="#0B1620")
        self.page = page
        self.volver_atras = volver_atras
        self.conexion = ConexionDB()

        self.ACCENT = "#0EA5A4"
        self.SURFACE = "#09121A"
        self.PAPER = "#07121A"
        self.TEXT_PRIMARY = "#E6F6F5"
        self.TEXT_MUTED = "#98B7B5"
        self.SEPARATOR = "#123239"

        self.titulo = ft.Text("📦 Detalle de Ventas", size=22, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY)
        self.tabla = ft.DataTable(
            columns=[
                ft.DataColumn(ft.Text("ID detalle", color=self.TEXT_PRIMARY)),
                ft.DataColumn(ft.Text("Venta ID", color=self.TEXT_PRIMARY)),
                ft.DataColumn(ft.Text("Producto ID", color=self.TEXT_PRIMARY)),
                ft.DataColumn(ft.Text("Cantidad", color=self.TEXT_PRIMARY)),
                ft.DataColumn(ft.Text("Precio unitario", color=self.TEXT_PRIMARY)),
                ft.DataColumn(ft.Text("Subtotal", color=self.TEXT_PRIMARY)),
                ft.DataColumn(ft.Text("Acciones", color=self.TEXT_PRIMARY)),
            ],
            rows=[]
        )

        # botones (se usan en el header que ahora incluimos)
        self.btn_volver = ft.ElevatedButton("⬅️ Volver", on_click=lambda e: self.volver_atras(), style=ft.ButtonStyle(bgcolor="#0D2A30", color=self.TEXT_PRIMARY, shape=ft.RoundedRectangleBorder(radius=8)))
        self.btn_agregar = ft.ElevatedButton("➕ Agregar", on_click=self.mostrar_formulario_agregar, style=ft.ButtonStyle(bgcolor=self.ACCENT, color="white", shape=ft.RoundedRectangleBorder(radius=8)))

        self.main_area = ft.Container(expand=True)
        self.content = ft.Column([self._build_topbar(), ft.Container(self.main_area, expand=True, padding=ft.padding.all(18))], expand=True)

        self.cargar_detalles()

    def _build_topbar(self):
        return ft.Container(
            content=ft.Row(
                [self.btn_volver, ft.Container(width=12), ft.Text("Detalle de Ventas", color=self.TEXT_PRIMARY, size=20, weight=ft.FontWeight.BOLD), ft.Container(expand=True)]
            ),
            padding=ft.padding.symmetric(vertical=12, horizontal=18),
            bgcolor=self.SURFACE,
            border=ft.border.all(1, self.SEPARATOR),
            border_radius=8
        )

    def cargar_detalles(self):
        """Carga la tabla y monta la vista incluyendo el header con 'Agregar'."""
        print(">> cargar_detalles() llamado")
        self.tabla.rows.clear()
        conn = self.conexion.conectar()
        try:
            if conn is None:
                print("❌ No hay conexión")
                return
            cur = conn.cursor()
            cur.execute("SELECT id_detalle, id_venta, id_producto, cantidad, precio_unitario, subtotal FROM detalle_venta")
            filas = cur.fetchall()
            for r in filas:
                id_d = r[0]
                btn_editar = ft.IconButton(icon=ft.Icons.EDIT, tooltip="Editar", on_click=lambda e, _id=id_d: self.mostrar_formulario_editar_id(_id), icon_color=self.ACCENT)
                btn_borrar = ft.IconButton(icon=ft.Icons.DELETE, tooltip="Eliminar", icon_color="#EF4444", on_click=lambda e, _id=id_d: self.confirmar_eliminar_id(_id))
                self.tabla.rows.append(ft.DataRow(cells=[
                    ft.DataCell(ft.Text(str(r[0]), color=self.TEXT_PRIMARY)),
                    ft.DataCell(ft.Text(str(r[1]) if r[1] is not None else "", color=self.TEXT_PRIMARY)),
                    ft.DataCell(ft.Text(str(r[2]) if r[2] is not None else "", color=self.TEXT_PRIMARY)),
                    ft.DataCell(ft.Text(str(r[3]) if r[3] is not None else "", color=self.TEXT_PRIMARY)),
                    ft.DataCell(ft.Text(str(r[4]) if r[4] is not None else "", color=self.TEXT_PRIMARY)),
                    ft.DataCell(ft.Text(str(r[5]) if r[5] is not None else "", color=self.TEXT_PRIMARY)),
                    ft.DataCell(ft.Row([btn_editar, btn_borrar], spacing=6))
                ]))
            print(f">> {len(filas)} detalles añadidos")
        except Exception as ex:
            print(f"❌ Error al cargar detalle_venta: {ex}")
        finally:
            self.conexion.cerrar(conn)

        # Header con botones: volver + agregar (ahora sí está visible)
        header_row = ft.Row([self.btn_volver, self.btn_agregar], alignment=ft.MainAxisAlignment.START)

        card = ft.Container(
            content=ft.Column([self.titulo, header_row, ft.Divider(color=self.SEPARATOR), self.tabla], spacing=10),
            padding=ft.padding.all(16),
            bgcolor=self.SURFACE,
            border=ft.border.all(1, self.SEPARATOR),
            border_radius=8
        )

        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[card])
        try:
            self.page.update()
        except Exception:
            pass

    def mostrar_formulario_agregar(self, e=None):
        """Formulario agregar (text_style ya configurado en versiones previas)."""
        input_text_style = ft.TextStyle(color="white")
        label_style = ft.TextStyle(color=self.TEXT_MUTED)
        id_field = ft.TextField(label="ID (opcional)", hint_text="Dejar vacío para autoincrement", width=200, text_style=input_text_style, label_style=label_style)
        id_venta = ft.TextField(label="ID Venta", text_style=input_text_style, label_style=label_style)
        id_producto = ft.TextField(label="ID Producto", text_style=input_text_style, label_style=label_style)
        cantidad = ft.TextField(label="Cantidad", text_style=input_text_style, label_style=label_style)
        precio_unitario = ft.TextField(label="Precio unitario", text_style=input_text_style, label_style=label_style)
        subtotal = ft.TextField(label="Subtotal", text_style=input_text_style, label_style=label_style)

        def guardar(ev):
            id_val = (id_field.value or "").strip()
            conn = self.conexion.conectar()
            if conn is None:
                print("❌ No hay conexión")
                return
            try:
                cur = conn.cursor()
                if id_val != "":
                    try:
                        id_int = int(id_val)
                    except ValueError:
                        print("❌ ID inválido")
                        return
                    cur.execute("INSERT INTO detalle_venta (id_detalle, id_venta, id_producto, cantidad, precio_unitario, subtotal) VALUES (%s, %s, %s, %s, %s, %s)",
                                (id_int, id_venta.value, id_producto.value, cantidad.value, precio_unitario.value, subtotal.value))
                else:
                    cur.execute("INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario, subtotal) VALUES (%s, %s, %s, %s, %s)",
                                (id_venta.value, id_producto.value, cantidad.value, precio_unitario.value, subtotal.value))
                conn.commit()
                print(">> Detalle insertado correctamente")
                self.cargar_detalles()
            except mysql.connector.IntegrityError as ie:
                print(f"❌ Integridad DB: {ie}")
            except Exception as ex:
                print(f"❌ Error al agregar detalle_venta: {ex}")
            finally:
                self.conexion.cerrar(conn)

        form = ft.Container(
            content=ft.Column([
                ft.Text("➕ Nuevo Detalle de Venta", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY),
                ft.Divider(color=self.SEPARATOR),
                id_field, id_venta, id_producto, cantidad, precio_unitario, subtotal,
                ft.Row([ft.ElevatedButton("Cancelar", on_click=lambda e: self.cargar_detalles(), style=ft.ButtonStyle(bgcolor="#0D2A30", color=self.TEXT_PRIMARY)), ft.ElevatedButton("Guardar", on_click=guardar, style=ft.ButtonStyle(bgcolor=self.ACCENT, color="white"))], spacing=12)
            ], spacing=12),
            padding=ft.padding.all(16),
            bgcolor=self.SURFACE,
            border=ft.border.all(1, self.SEPARATOR),
            border_radius=8
        )

        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[form])
        try:
            self.page.update()
        except Exception:
            pass

    def mostrar_formulario_editar_id(self, id_detalle):
        conn = self.conexion.conectar()
        try:
            if conn is None:
                print("❌ No hay conexión")
                return
            cur = conn.cursor()
            cur.execute("SELECT id_venta, id_producto, cantidad, precio_unitario, subtotal FROM detalle_venta WHERE id_detalle = %s", (id_detalle,))
            datos = cur.fetchone()
            if not datos:
                print("❌ Detalle no encontrado")
                self.cargar_detalles()
                return
            input_text_style = ft.TextStyle(color="white")
            label_style = ft.TextStyle(color=self.TEXT_MUTED)
            id_venta = ft.TextField(label="ID Venta", value=str(datos[0]) if datos[0] is not None else "", text_style=input_text_style, label_style=label_style)
            id_producto = ft.TextField(label="ID Producto", value=str(datos[1]) if datos[1] is not None else "", text_style=input_text_style, label_style=label_style)
            cantidad = ft.TextField(label="Cantidad", value=str(datos[2]) if datos[2] is not None else "", text_style=input_text_style, label_style=label_style)
            precio_unitario = ft.TextField(label="Precio unitario", value=str(datos[3]) if datos[3] is not None else "", text_style=input_text_style, label_style=label_style)
            subtotal = ft.TextField(label="Subtotal", value=str(datos[4]) if datos[4] is not None else "", text_style=input_text_style, label_style=label_style)
        except Exception as ex:
            print(f"❌ Error al cargar detalle: {ex}")
            return
        finally:
            self.conexion.cerrar(conn)

        def guardar(ev):
            conn2 = self.conexion.conectar()
            if conn2 is None:
                print("❌ No hay conexión")
                return
            try:
                cur2 = conn2.cursor()
                cur2.execute("UPDATE detalle_venta SET id_venta=%s, id_producto=%s, cantidad=%s, precio_unitario=%s, subtotal=%s WHERE id_detalle=%s",
                             (id_venta.value, id_producto.value, cantidad.value, precio_unitario.value, subtotal.value, id_detalle))
                conn2.commit()
                print(">> Detalle actualizado correctamente")
                self.cargar_detalles()
            except Exception as ex:
                print(f"❌ Error al actualizar detalle: {ex}")
            finally:
                self.conexion.cerrar(conn2)

        form = ft.Container(
            content=ft.Column([
                ft.Text(f"✏️ Editar Detalle (ID: {id_detalle})", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY),
                ft.Divider(color=self.SEPARATOR),
                id_venta, id_producto, cantidad, precio_unitario, subtotal,
                ft.Row([ft.ElevatedButton("Cancelar", on_click=lambda e: self.cargar_detalles(), style=ft.ButtonStyle(bgcolor="#0D2A30", color=self.TEXT_PRIMARY)), ft.ElevatedButton("Guardar", on_click=guardar, style=ft.ButtonStyle(bgcolor=self.ACCENT, color="white"))], spacing=12)
            ], spacing=12),
            padding=ft.padding.all(16),
            bgcolor=self.SURFACE,
            border=ft.border.all(1, self.SEPARATOR),
            border_radius=8
        )

        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[form])
        try:
            self.page.update()
        except Exception:
            pass

    def confirmar_eliminar_id(self, id_detalle):
        def eliminar(ev):
            conn = self.conexion.conectar()
            try:
                if conn is None:
                    print("❌ No hay conexión")
                    return
                cur = conn.cursor()
                cur.execute("DELETE FROM detalle_venta WHERE id_detalle = %s", (id_detalle,))
                conn.commit()
                print(">> Detalle eliminado correctamente")
                self.cargar_detalles()
            except Exception as ex:
                print(f"❌ Error al eliminar detalle: {ex}")
            finally:
                self.conexion.cerrar(conn)
        confirm = ft.Container(
            content=ft.Column([
                ft.Text("⚠️ Confirmar eliminación", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY),
                ft.Text(f"¿Eliminar detalle ID: {id_detalle}?", color=self.TEXT_MUTED),
                ft.Row([ft.ElevatedButton("Cancelar", on_click=lambda e: self.cargar_detalles(), style=ft.ButtonStyle(bgcolor="#0D2A30", color=self.TEXT_PRIMARY)), ft.ElevatedButton("Eliminar", on_click=eliminar, style=ft.ButtonStyle(bgcolor="#EF4444", color="white"))], spacing=12)
            ], spacing=12),
            padding=ft.padding.all(16),
            bgcolor=self.SURFACE,
            border=ft.border.all(1, self.SEPARATOR),
            border_radius=8
        )
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[confirm])
        try:
            self.page.update()
        except Exception:
            pass