import mysql.connector
from mysql.connector import Error
from muebles.config import DB_CONFIG

class ConexionDB:
    def __init__(self):
        self.host = DB_CONFIG["host"]
        self.user = DB_CONFIG["user"]
        self.password = DB_CONFIG["password"]
        self.database = DB_CONFIG["database"]

    def conectar(self):
        """Establece conexión con la base de datos"""
        try:
            conexion = mysql.connector.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database,
                autocommit=False,
                charset='utf8mb4',
                collation='utf8mb4_unicode_ci'
            )
            if conexion.is_connected():
                return conexion
        except Error as e:
            print(f"❌ Error al conectar con la base de datos: {e}")
        except Exception as e:
            print(f"❌ Error inesperado: {e}")
        return None

    def cerrar(self, conexion):
        """Cierra la conexión de forma segura"""
        try:
            if conexion and getattr(conexion, "is_connected", lambda: False)():
                conexion.close()
        except Exception as e:
            print(f"⚠️ Error al cerrar conexión: {e}")

    def test_connection(self):
        """Prueba la conexión a la base de datos"""
        conn = self.conectar()
        if conn:
            self.cerrar(conn)
            return True
        return False