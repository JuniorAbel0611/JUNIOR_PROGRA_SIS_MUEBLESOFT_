import flet as ft
from muebles.conexion import ConexionDB
import mysql.connector

class ComprasView(ft.Container):
    """
    Compras view - UI adaptada al tema oscuro y text_style en campos.
    CRUD sin cambios.
    """
    def __init__(self, page, volver_atras):
        super().__init__(expand=True, bgcolor="#0B1620")
        self.page = page
        self.volver_atras = volver_atras
        self.conexion = ConexionDB()

        self.ACCENT = "#0EA5A4"
        self.SURFACE = "#09121A"
        self.PAPER = "#07121A"
        self.TEXT_PRIMARY = "#E6F6F5"
        self.TEXT_MUTED = "#98B7B5"
        self.SEPARATOR = "#123239"
        self.btn_primary = ft.ButtonStyle(bgcolor=self.ACCENT, color="white", shape=ft.RoundedRectangleBorder(radius=8))
        self.btn_secondary = ft.ButtonStyle(bgcolor="#0D2A30", color=self.TEXT_PRIMARY, shape=ft.RoundedRectangleBorder(radius=8))

        self.titulo = ft.Text("🧾 Gestión de Compras", size=22, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY)
        self.tabla = ft.DataTable(columns=[ft.DataColumn(ft.Text("ID", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Proveedor ID", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Usuario ID", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Fecha", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Total", color=self.TEXT_PRIMARY)), ft.DataColumn(ft.Text("Acciones", color=self.TEXT_PRIMARY))], rows=[])
        self.btn_volver = ft.ElevatedButton("⬅️ Volver", on_click=lambda e: self.volver_atras(), style=self.btn_secondary)
        self.btn_agregar = ft.ElevatedButton("➕ Agregar", on_click=self.mostrar_formulario_agregar, style=self.btn_primary)

        self.main_area = ft.Container(expand=True)
        self.content = ft.Column([self._build_topbar(), ft.Row([self._build_left_panel(), ft.Container(self.main_area, expand=True, padding=ft.padding.all(18))], spacing=12, expand=True)], expand=True)

        self.cargar_compras()

    def _build_topbar(self):
        return ft.Container(content=ft.Row([self.btn_volver, ft.Container(width=12), ft.Text("Compras — Panel", color=self.TEXT_PRIMARY, size=20, weight=ft.FontWeight.BOLD), ft.Container(expand=True)]), padding=ft.padding.symmetric(vertical=12, horizontal=18), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)

    def _build_left_panel(self):
        btn_add = ft.ElevatedButton("➕ Nueva compra", on_click=lambda e: self.mostrar_formulario_agregar(), style=self.btn_primary, width=180)
        btn_refresh = ft.ElevatedButton("🔁 Refrescar", on_click=lambda e: self.cargar_compras(), style=self.btn_secondary, width=180)
        panel = ft.Container(content=ft.Column([ft.Text("Acciones rápidas", weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY), ft.Text("Crear y refrescar compras", size=12, color=self.TEXT_MUTED), ft.Divider(color=self.SEPARATOR), btn_add, ft.Container(height=8), btn_refresh, ft.Container(expand=True)], spacing=10), padding=ft.padding.all(14), bgcolor=self.PAPER, border=ft.border.all(1, self.SEPARATOR), border_radius=8, width=260)
        return panel

    def switch_view(self, widget):
        self.main_area.content = widget
        try:
            self.page.update()
        except Exception:
            pass

    def cargar_compras(self):
        print(">> cargar_compras() llamado")
        self.tabla.rows.clear()
        conn = self.conexion.conectar()
        try:
            if conn is None:
                print("❌ No hay conexión")
                return
            cur = conn.cursor()
            cur.execute("SELECT id_compra, id_proveedor, id_usuario, fecha_compra, total FROM compras")
            filas = cur.fetchall()
            for r in filas:
                id_c = r[0]
                btn_editar = ft.IconButton(icon=ft.Icons.EDIT, tooltip="Editar", on_click=lambda e, _id=id_c: self.mostrar_formulario_editar_id(_id), icon_color=self.ACCENT)
                btn_borrar = ft.IconButton(icon=ft.Icons.DELETE, tooltip="Eliminar", icon_color="#EF4444", on_click=lambda e, _id=id_c: self.confirmar_eliminar_id(_id))
                self.tabla.rows.append(ft.DataRow(cells=[ft.DataCell(ft.Text(str(r[0]), color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(str(r[1]) if r[1] is not None else "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(str(r[2]) if r[2] is not None else "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(str(r[3]) if r[3] is not None else "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Text(str(r[4]) if r[4] is not None else "", color=self.TEXT_PRIMARY)), ft.DataCell(ft.Row([btn_editar, btn_borrar], spacing=6))]))
            print(f">> {len(filas)} compras añadidas")
        except Exception as ex:
            print(f"❌ Error al cargar compras: {ex}")
        finally:
            self.conexion.cerrar(conn)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[ft.Container(content=ft.Column([self.titulo, ft.Divider(color=self.SEPARATOR), self.tabla], spacing=10), padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)])
        try:
            self.page.update()
        except Exception:
            pass

    def mostrar_formulario_agregar(self, e=None):
        input_text_style = ft.TextStyle(color="white")
        label_style = ft.TextStyle(color=self.TEXT_MUTED)

        id_field = ft.TextField(label="ID (opcional)", hint_text="Dejar vacío para autoincrement", width=200, text_style=input_text_style, label_style=label_style)
        id_proveedor = ft.TextField(label="ID Proveedor", text_style=input_text_style, label_style=label_style)
        id_usuario = ft.TextField(label="ID Usuario", text_style=input_text_style, label_style=label_style)
        fecha = ft.TextField(label="Fecha (YYYY-MM-DD HH:MM:SS)", text_style=input_text_style, label_style=label_style)
        total = ft.TextField(label="Total", text_style=input_text_style, label_style=label_style)

        def guardar(ev):
            id_val = (id_field.value or "").strip()
            conn = self.conexion.conectar()
            if conn is None:
                print("❌ No hay conexión")
                return
            try:
                cur = conn.cursor()
                if id_val != "":
                    try:
                        id_int = int(id_val)
                    except ValueError:
                        print("❌ ID inválido")
                        return
                    cur.execute("INSERT INTO compras (id_compra, id_proveedor, id_usuario, fecha_compra, total) VALUES (%s, %s, %s, %s, %s)", (id_int, id_proveedor.value, id_usuario.value, fecha.value, total.value))
                else:
                    cur.execute("INSERT INTO compras (id_proveedor, id_usuario, fecha_compra, total) VALUES (%s, %s, %s, %s)", (id_proveedor.value, id_usuario.value, fecha.value, total.value))
                conn.commit()
                print(">> Compra insertada correctamente")
                self._build_table_view()
                self.cargar_compras()
            except mysql.connector.IntegrityError as ie:
                print(f"❌ Integridad DB: {ie}")
            except Exception as ex:
                print(f"❌ Error al agregar compra: {ex}")
            finally:
                self.conexion.cerrar(conn)

        form = ft.Container(content=ft.Column([ft.Text("➕ Nueva Compra", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY), ft.Divider(color=self.SEPARATOR), id_field, id_proveedor, id_usuario, fecha, total, ft.Row([ft.ElevatedButton("Cancelar", on_click=lambda e: (self._build_table_view(), self.cargar_compras()), style=self.btn_secondary), ft.ElevatedButton("Guardar", on_click=guardar, style=self.btn_primary)], spacing=12)], spacing=12), padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[form])
        try:
            self.page.update()
        except Exception:
            pass