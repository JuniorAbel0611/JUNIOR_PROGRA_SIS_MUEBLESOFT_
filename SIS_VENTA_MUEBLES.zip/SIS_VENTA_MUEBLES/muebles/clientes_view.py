import flet as ft
from muebles.conexion import ConexionDB
from muebles.config import THEME
from muebles.components import (
    ModernCard, ModernButton, ModernTextField, ModernDataTable,
    create_snackbar, LoadingIndicator
)
from muebles.utils import validate_required, validate_dni, validate_phone
import mysql.connector

class ClientesView(ft.Container):
    """
    Vista de Clientes completamente rediseñada
    Diseño moderno, responsivo y con mejor UX
    """
    def __init__(self, page, volver_atras):
        super().__init__(expand=True, bgcolor=THEME["bg_primary"])
        self.page = page
        self.volver_atras = volver_atras
        self.conexion = ConexionDB()
        self.table_name = "clientes"
        self.pk_column = "id_cliente"

        self.main_area = ft.Container(expand=True)
        
        # Layout principal
        self.content = ft.Column(
            [
                self._build_topbar(),
                ft.ResponsiveRow(
                    [
                        ft.Container(
                            content=self._build_sidebar(),
                            col={"sm": 12, "md": 3},
                            padding=ft.padding.all(THEME["spacing_md"])
                        ),
                        ft.Container(
                            content=self.main_area,
                            col={"sm": 12, "md": 9},
                            padding=ft.padding.all(THEME["spacing_md"]),
                            expand=True
                        )
                    ],
                    spacing=THEME["spacing_md"],
                    expand=True
                )
            ],
            spacing=0,
            expand=True
        )

        # Cargar datos iniciales
        self.cargar_clientes()

    def _build_topbar(self):
        """Construye la barra superior"""
        return ft.Container(
            content=ft.Row(
                [
                    ModernButton(
                        "← Volver",
                        style_type="secondary",
                        on_click=lambda e: self.volver_atras(),
                        height=40
                    ),
                    ft.Container(width=THEME["spacing_md"]),
                    ft.Icon(ft.Icons.PEOPLE, color="#3B82F6", size=24),
                    ft.Container(width=THEME["spacing_sm"]),
                    ft.Column(
                        [
                            ft.Text(
                                "Clientes",
                                size=22,
                                weight=ft.FontWeight.BOLD,
                                color=THEME["text_primary"]
                            ),
                            ft.Text(
                                "Gestión completa de clientes",
                                size=12,
                                color=THEME["text_muted"]
                            )
                        ],
                        spacing=0
                    ),
                    ft.Container(expand=True),
                    ft.Container(
                        content=ft.Row(
                            [
                                ModernButton(
                                    "➕ Nuevo",
                                    style_type="primary",
                                    on_click=lambda e: self.mostrar_formulario_agregar(),
                                    height=40
                                ),
                                ft.Container(width=THEME["spacing_sm"]),
                                ModernButton(
                                    "🔄 Refrescar",
                                    style_type="secondary",
                                    on_click=lambda e: self.cargar_clientes(),
                                    height=40
                                )
                            ],
                            spacing=THEME["spacing_sm"]
                        )
                    )
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER
            ),
            padding=ft.padding.symmetric(
                horizontal=THEME["spacing_xl"],
                vertical=THEME["spacing_lg"]
            ),
            bgcolor=THEME["bg_card"],
            border=ft.border.only(
                bottom=ft.BorderSide(1, THEME["border"])
            )
        )

    def _build_sidebar(self):
        """Construye la barra lateral"""
        return ModernCard(
            content=ft.Column(
                [
                    ft.Text(
                        "Acciones Rápidas",
                        size=16,
                        weight=ft.FontWeight.BOLD,
                        color=THEME["text_primary"]
                    ),
                    ft.Divider(color=THEME["divider"], height=1),
                    ft.Container(height=THEME["spacing_md"]),
                    ModernButton(
                        "➕ Agregar Cliente",
                        style_type="primary",
                        on_click=lambda e: self.mostrar_formulario_agregar(),
                        width=200
                    ),
                    ft.Container(height=THEME["spacing_sm"]),
                    ModernButton(
                        "🔄 Refrescar",
                        style_type="secondary",
                        on_click=lambda e: self.cargar_clientes(),
                        width=200
                    ),
                    ft.Container(expand=True)
                ],
                spacing=THEME["spacing_sm"]
            ),
            width=250
        )

    def cargar_clientes(self):
        """Carga y muestra la tabla de clientes"""
        self._show_loading()
        
        # Definir columnas de la tabla
        columns = [
            ft.DataColumn(ft.Text("ID", color=THEME["text_primary"], weight=ft.FontWeight.BOLD)),
            ft.DataColumn(ft.Text("Nombre", color=THEME["text_primary"], weight=ft.FontWeight.BOLD)),
            ft.DataColumn(ft.Text("DNI", color=THEME["text_primary"], weight=ft.FontWeight.BOLD)),
            ft.DataColumn(ft.Text("Teléfono", color=THEME["text_primary"], weight=ft.FontWeight.BOLD)),
            ft.DataColumn(ft.Text("Dirección", color=THEME["text_primary"], weight=ft.FontWeight.BOLD)),
            ft.DataColumn(ft.Text("Acciones", color=THEME["text_primary"], weight=ft.FontWeight.BOLD)),
        ]

        tabla = ModernDataTable(columns=columns)

        conn = self.conexion.conectar()
        if conn is None:
            self._show_error("No hay conexión a la base de datos")
            return

        try:
            cur = conn.cursor()
            cur.execute("SELECT id_cliente, nombre_cliente, dni, telefono, direccion FROM clientes ORDER BY id_cliente DESC")
            filas = cur.fetchall()
            
            for cli in filas:
                idc = cli[0]
                btn_edit = ft.IconButton(
                    icon=ft.Icons.EDIT,
                    tooltip="Editar",
                    icon_color=THEME["primary"],
                    on_click=lambda e, _id=idc: self.mostrar_formulario_editar(_id)
                )
                btn_delete = ft.IconButton(
                    icon=ft.Icons.DELETE,
                    tooltip="Eliminar",
                    icon_color=THEME["error"],
                    on_click=lambda e, _id=idc: self.confirmar_eliminar(_id)
                )
                
                tabla.rows.append(
                    ft.DataRow(
                        cells=[
                            ft.DataCell(ft.Text(str(cli[0]), color=THEME["text_primary"])),
                            ft.DataCell(ft.Text(cli[1] or "", color=THEME["text_primary"])),
                            ft.DataCell(ft.Text(cli[2] or "", color=THEME["text_primary"])),
                            ft.DataCell(ft.Text(cli[3] or "", color=THEME["text_primary"])),
                            ft.DataCell(ft.Text(cli[4] or "", color=THEME["text_primary"])),
                            ft.DataCell(ft.Row([btn_edit, btn_delete], spacing=4))
                        ]
                    )
                )
        except Exception as ex:
            self._show_error(f"Error al cargar clientes: {ex}")
        finally:
            self.conexion.cerrar(conn)

        # Mostrar tabla en contenedor
        card = ModernCard(
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.Text(
                                f"Lista de Clientes ({len(filas)} registros)",
                                size=18,
                                weight=ft.FontWeight.BOLD,
                                color=THEME["text_primary"]
                            ),
                            ft.Container(expand=True)
                        ]
                    ),
                    ft.Divider(color=THEME["divider"]),
                    ft.Container(
                        content=tabla,
                        expand=True
                    )
                ],
                spacing=THEME["spacing_md"],
                expand=True
            )
        )

        self.main_area.content = ft.ListView(
            expand=True,
            padding=ft.padding.all(THEME["spacing_sm"]),
            controls=[card]
        )
        self.page.update()

    def mostrar_formulario_agregar(self, e=None):
        """Muestra formulario para agregar cliente"""
        nombre = ModernTextField(label="Nombre Completo *", width=400)
        dni = ModernTextField(label="DNI *", width=400, hint_text="8 dígitos")
        telefono = ModernTextField(label="Teléfono *", width=400)
        direccion = ModernTextField(label="Dirección", width=400, multiline=True, min_lines=2, max_lines=3)

        def guardar(ev):
            # Validaciones
            valid, msg = validate_required(nombre.value, "Nombre")
            if not valid:
                self._show_message(msg, "error")
                return

            valid, msg = validate_required(dni.value, "DNI")
            if not valid:
                self._show_message(msg, "error")
                return

            if not validate_dni(dni.value):
                self._show_message("DNI debe tener 8 dígitos", "error")
                return

            valid, msg = validate_required(telefono.value, "Teléfono")
            if not valid:
                self._show_message(msg, "error")
                return

            conn = self.conexion.conectar()
            if conn is None:
                self._show_message("No hay conexión a la base de datos", "error")
                return

            try:
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO clientes (nombre_cliente, dni, telefono, direccion) VALUES (%s, %s, %s, %s)",
                    (nombre.value, dni.value, telefono.value, direccion.value)
                )
                conn.commit()
                self._show_message("Cliente agregado correctamente", "success")
                self.cargar_clientes()
            except mysql.connector.IntegrityError as ie:
                self._show_message(f"Error: El DNI ya existe en el sistema", "error")
            except Exception as ex:
                self._show_message(f"Error al agregar cliente: {ex}", "error")
            finally:
                self.conexion.cerrar(conn)

        form_card = ModernCard(
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.Icon(ft.Icons.PERSON_ADD, color=THEME["primary"], size=28),
                            ft.Text(
                                "Nuevo Cliente",
                                size=20,
                                weight=ft.FontWeight.BOLD,
                                color=THEME["text_primary"]
                            )
                        ],
                        spacing=THEME["spacing_sm"]
                    ),
                    ft.Divider(color=THEME["divider"]),
                    nombre,
                    dni,
                    telefono,
                    direccion,
                    ft.Container(height=THEME["spacing_md"]),
                    ft.Row(
                        [
                            ModernButton(
                                "Cancelar",
                                style_type="secondary",
                                on_click=lambda e: self.cargar_clientes(),
                                width=150
                            ),
                            ModernButton(
                                "Guardar",
                                style_type="primary",
                                on_click=guardar,
                                width=150
                            )
                        ],
                        alignment=ft.MainAxisAlignment.END
                    )
                ],
                spacing=THEME["spacing_md"]
            )
        )

        self.main_area.content = ft.ListView(
            expand=True,
            padding=ft.padding.all(THEME["spacing_md"]),
            controls=[form_card]
        )
        self.page.update()

    def mostrar_formulario_editar(self, id_cliente):
        """Muestra formulario para editar cliente"""
        conn = self.conexion.conectar()
        if conn is None:
            self._show_message("No hay conexión a la base de datos", "error")
            return

        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT nombre_cliente, dni, telefono, direccion FROM clientes WHERE id_cliente=%s",
                (id_cliente,)
            )
            datos = cur.fetchone()
            
            if not datos:
                self._show_message("Cliente no encontrado", "error")
                self.cargar_clientes()
                return

            nombre = ModernTextField(label="Nombre Completo *", value=datos[0] or "", width=400)
            dni = ModernTextField(label="DNI *", value=datos[1] or "", width=400)
            telefono = ModernTextField(label="Teléfono *", value=datos[2] or "", width=400)
            direccion = ModernTextField(label="Dirección", value=datos[3] or "", width=400, multiline=True, min_lines=2, max_lines=3)

        except Exception as ex:
            self._show_message(f"Error al cargar cliente: {ex}", "error")
            return
        finally:
            self.conexion.cerrar(conn)

        def guardar(ev):
            # Validaciones
            valid, msg = validate_required(nombre.value, "Nombre")
            if not valid:
                self._show_message(msg, "error")
                return

            conn2 = self.conexion.conectar()
            if conn2 is None:
                self._show_message("No hay conexión a la base de datos", "error")
                return

            try:
                cur2 = conn2.cursor()
                cur2.execute(
                    "UPDATE clientes SET nombre_cliente=%s, dni=%s, telefono=%s, direccion=%s WHERE id_cliente=%s",
                    (nombre.value, dni.value, telefono.value, direccion.value, id_cliente)
                )
                conn2.commit()
                self._show_message("Cliente actualizado correctamente", "success")
                self.cargar_clientes()
            except Exception as ex:
                self._show_message(f"Error al editar cliente: {ex}", "error")
            finally:
                self.conexion.cerrar(conn2)

        form_card = ModernCard(
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.Icon(ft.Icons.EDIT, color=THEME["primary"], size=28),
                            ft.Text(
                                f"Editar Cliente (ID: {id_cliente})",
                                size=20,
                                weight=ft.FontWeight.BOLD,
                                color=THEME["text_primary"]
                            )
                        ],
                        spacing=THEME["spacing_sm"]
                    ),
                    ft.Divider(color=THEME["divider"]),
                    nombre,
                    dni,
                    telefono,
                    direccion,
                    ft.Container(height=THEME["spacing_md"]),
                    ft.Row(
                        [
                            ModernButton(
                                "Cancelar",
                                style_type="secondary",
                                on_click=lambda e: self.cargar_clientes(),
                                width=150
                            ),
                            ModernButton(
                                "Guardar",
                                style_type="primary",
                                on_click=guardar,
                                width=150
                            )
                        ],
                        alignment=ft.MainAxisAlignment.END
                    )
                ],
                spacing=THEME["spacing_md"]
            )
        )

        self.main_area.content = ft.ListView(
            expand=True,
            padding=ft.padding.all(THEME["spacing_md"]),
            controls=[form_card]
        )
        self.page.update()

    def confirmar_eliminar(self, id_cliente):
        """Confirma eliminación de cliente"""
        def eliminar(ev):
            conn = self.conexion.conectar()
            if conn is None:
                self._show_message("No hay conexión a la base de datos", "error")
                return

            try:
                cur = conn.cursor()
                cur.execute("DELETE FROM clientes WHERE id_cliente=%s", (id_cliente,))
                conn.commit()
                self._show_message("Cliente eliminado correctamente", "success")
                self.cargar_clientes()
            except Exception as ex:
                self._show_message(f"Error al eliminar cliente: {ex}", "error")
            finally:
                self.conexion.cerrar(conn)
            
            if self.page.dialog:
                self.page.dialog.open = False
                self.page.update()

        dlg = ft.AlertDialog(
            modal=True,
            title=ft.Text("Confirmar eliminación", color=THEME["text_primary"]),
            content=ft.Text(
                f"¿Estás seguro de eliminar el cliente ID: {id_cliente}? Esta acción no se puede deshacer.",
                color=THEME["text_secondary"]
            ),
            bgcolor=THEME["bg_card"],
            actions=[
                ft.TextButton(
                    "Cancelar",
                    on_click=lambda e: self._close_dialog(),
                    style=ft.ButtonStyle(color=THEME["text_secondary"])
                ),
                ft.ElevatedButton(
                    "Eliminar",
                    on_click=eliminar,
                    style=ft.ButtonStyle(
                        bgcolor=THEME["error"],
                        color="white",
                        shape=ft.RoundedRectangleBorder(radius=THEME["radius_md"])
                    )
                )
            ]
        )
        self.page.dialog = dlg
        dlg.open = True
        self.page.update()

    def _close_dialog(self):
        """Cierra el diálogo actual"""
        if self.page.dialog:
            self.page.dialog.open = False
            self.page.update()

    def _show_message(self, message: str, type: str = "info"):
        """Muestra un mensaje al usuario"""
        snackbar = create_snackbar(message, type)
        self.page.show_snack_bar(snackbar)

    def _show_error(self, message: str):
        """Muestra un error en el área principal"""
        self.main_area.content = ModernCard(
            content=ft.Column(
                [
                    ft.Icon(ft.Icons.ERROR_OUTLINE, color=THEME["error"], size=48),
                    ft.Text(message, color=THEME["error"], size=16)
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=THEME["spacing_md"]
            )
        )
        self.page.update()

    def _show_loading(self):
        """Muestra indicador de carga"""
        self.main_area.content = LoadingIndicator()
        self.page.update()
