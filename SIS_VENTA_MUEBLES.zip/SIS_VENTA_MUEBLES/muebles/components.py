"""
Componentes reutilizables para la interfaz
Diseño moderno y responsivo
"""
import flet as ft
from muebles.config import THEME, BUTTON_STYLES

def color_with_opacity(hex_color: str, opacity: float) -> str:
    """
    Devuelve un color en formato #AARRGGBB aplicando la opacidad (0.0 - 1.0)
    hex_color puede ser "#RRGGBB" o "#AARRGGBB". Si ya tiene alpha, se mantiene.
    """
    if not hex_color:
        return hex_color
    c = hex_color.lstrip('#')
    # Si ya tiene 8 dígitos (AARRGGBB), devolvemos tal cual
    if len(c) == 8:
        return f"#{c.upper()}"
    # Si tiene 6 dígitos (RRGGBB), añadimos alpha al principio (AARRGGBB)
    if len(c) == 6:
        try:
            alpha = max(0, min(255, int(opacity * 255)))
        except Exception:
            alpha = int(255 * 1.0)
        a_hex = format(alpha, "02X")
        return f"#{a_hex}{c.upper()}"
    # Si viene en otro formato, devolver como estaba
    return hex_color

class ModernCard(ft.Container):
    """Tarjeta moderna con sombra y hover"""
    def __init__(self, content, **kwargs):
        super().__init__(
            content=content,
            bgcolor=THEME["bg_card"],
            border_radius=THEME["radius_lg"],
            padding=ft.padding.all(THEME["spacing_md"]),
            border=ft.border.all(1, THEME["border"]),
            shadow=ft.BoxShadow(
                spread_radius=0,
                blur_radius=10,
                color=color_with_opacity("#000000", 0.3),
                offset=ft.Offset(0, 2)
            ),
            **kwargs
        )

class ModernButton(ft.ElevatedButton):
    """Botón moderno con estilos predefinidos"""
    def __init__(self, text, style_type="primary", on_click=None, **kwargs):
        style_config = BUTTON_STYLES.get(style_type, BUTTON_STYLES["primary"])
        super().__init__(
            text=text,
            on_click=on_click,
            style=ft.ButtonStyle(
                bgcolor=style_config["bgcolor"],
                color=style_config["color"],
                shape=ft.RoundedRectangleBorder(radius=style_config["radius"]),
                padding=ft.padding.symmetric(
                    horizontal=THEME["spacing_lg"],
                    vertical=THEME["spacing_md"]
                ),
            ),
            **kwargs
        )

class ModernTextField(ft.TextField):
    """Campo de texto moderno con estilos consistentes"""
    def __init__(self, label="", hint_text="", value="", password=False, **kwargs):
        super().__init__(
            label=label,
            hint_text=hint_text,
            value=value,
            password=password,
            can_reveal_password=password,
            text_style=ft.TextStyle(color=THEME["text_primary"]),
            label_style=ft.TextStyle(color=THEME["text_secondary"]),
            hint_style=ft.TextStyle(color=THEME["text_muted"]),
            bgcolor=THEME["bg_secondary"],
            border_color=THEME["border"],
            focused_border_color=THEME["primary"],
            border_radius=THEME["radius_md"],
            content_padding=ft.padding.symmetric(
                horizontal=THEME["spacing_md"],
                vertical=THEME["spacing_sm"]
            ),
            **kwargs
        )

class ModernDataTable(ft.DataTable):
    """Tabla de datos moderna y responsiva"""
    def __init__(self, columns, rows=None, **kwargs):
        super().__init__(
            columns=columns,
            rows=rows or [],
            heading_row_color=THEME["bg_tertiary"],
            heading_row_height=48,
            data_row_min_height=48,
            data_row_max_height=72,
            horizontal_lines=ft.BorderSide(1, THEME["border"]),
            vertical_lines=ft.BorderSide(1, THEME["border"]),
            border=ft.border.all(1, THEME["border"]),
            border_radius=THEME["radius_md"],
            **kwargs
        )

class ResponsiveContainer(ft.Container):
    """Contenedor responsivo que se adapta al tamaño de pantalla"""
    def __init__(self, content, mobile_content=None, **kwargs):
        self.mobile_content = mobile_content
        super().__init__(content=content, **kwargs)

class LoadingIndicator(ft.Container):
    """Indicador de carga moderno"""
    def __init__(self):
        super().__init__(
            content=ft.Column(
                [
                    ft.ProgressRing(color=THEME["primary"], width=40, height=40),
                    ft.Text("Cargando...", color=THEME["text_secondary"], size=14)
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=THEME["spacing_md"]
            ),
            alignment=ft.alignment.center,
            expand=True
        )

class AlertDialog(ft.AlertDialog):
    """Diálogo de alerta moderno"""
    def __init__(self, title, content, confirm_text="Aceptar", cancel_text="Cancelar", 
                 on_confirm=None, on_cancel=None, type="info"):
        colors = {
            "info": THEME["info"],
            "success": THEME["success"],
            "warning": THEME["warning"],
            "error": THEME["error"]
        }
        color = colors.get(type, THEME["info"])
        
        super().__init__(
            modal=True,
            title=ft.Text(title, size=18, weight=ft.FontWeight.BOLD, color=THEME["text_primary"]),
            content=ft.Container(
                content=content,
                padding=ft.padding.only(top=THEME["spacing_md"])
            ),
            bgcolor=THEME["bg_card"],
            actions=[
                ft.TextButton(
                    cancel_text,
                    on_click=on_cancel or (lambda e: self.close()),
                    style=ft.ButtonStyle(color=THEME["text_secondary"])
                ) if cancel_text else None,
                ft.ElevatedButton(
                    confirm_text,
                    on_click=on_confirm or (lambda e: self.close()),
                    style=ft.ButtonStyle(
                        bgcolor=color,
                        color="white",
                        shape=ft.RoundedRectangleBorder(radius=THEME["radius_md"])
                    )
                )
            ],
            actions_alignment=ft.MainAxisAlignment.END
        )
        # Filtrar None de actions
        self.actions = [a for a in self.actions if a is not None]

def create_snackbar(message: str, type: str = "info", duration: int = 3000) -> ft.SnackBar:
    """Crea un snackbar moderno"""
    colors = {
        "info": THEME["info"],
        "success": THEME["success"],
        "warning": THEME["warning"],
        "error": THEME["error"]
    }
    color = colors.get(type, THEME["info"])
    
    return ft.SnackBar(
        content=ft.Text(message, color="white"),
        bgcolor=color,
        duration=duration,
        action="Cerrar",
        action_color="white"
    )

def create_stat_card(title: str, value: str, icon: str, color: str = THEME["primary"]) -> ModernCard:
    """Crea una tarjeta de estadística"""
    return ModernCard(
        content=ft.Column(
            [
                ft.Row(
                    [
                        ft.Icon(icon, color=color, size=24),
                        ft.Container(expand=True),
                        ft.Text(value, size=24, weight=ft.FontWeight.BOLD, color=THEME["text_primary"])
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),
                ft.Container(height=THEME["spacing_sm"]),
                ft.Text(title, size=12, color=THEME["text_muted"])
            ],
            spacing=0
        ),
        width=200,
        height=120
    )