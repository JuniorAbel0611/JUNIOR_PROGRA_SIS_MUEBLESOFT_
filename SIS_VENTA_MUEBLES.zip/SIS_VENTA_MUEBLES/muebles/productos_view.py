import flet as ft
from muebles.conexion import ConexionDB
import mysql.connector

class ProductosView(ft.Container):
    """
    Productos view - diseño adaptado al tema oscuro y estilo uniforme.
    Solo cambios visuales: paleta, layout, text styles. Lógica CRUD intacta.
    """
    def __init__(self, page, volver_atras):
        super().__init__(expand=True, bgcolor="#0B1620")
        self.page = page
        self.volver_atras = volver_atras
        self.conexion = ConexionDB()

        # Paleta / estilos
        self.ACCENT = "#0EA5A4"
        self.SURFACE = "#09121A"
        self.PAPER = "#07121A"
        self.TEXT_PRIMARY = "#E6F6F5"
        self.TEXT_MUTED = "#98B7B5"
        self.SEPARATOR = "#123239"
        self.btn_primary = ft.ButtonStyle(bgcolor=self.ACCENT, color="white", shape=ft.RoundedRectangleBorder(radius=8))
        self.btn_secondary = ft.ButtonStyle(bgcolor="#0D2A30", color=self.TEXT_PRIMARY, shape=ft.RoundedRectangleBorder(radius=8))

        # Área dinámica
        self.main_area = ft.Container(expand=True)

        # Layout general
        self.content = ft.Column(
            [
                self._build_topbar(),
                ft.Row([self._build_left_panel(), ft.Container(self.main_area, expand=True, padding=ft.padding.all(18))], spacing=12, expand=True)
            ],
            expand=True
        )

        # cargar metadata y datos
        self._load_metadata()
        self._rebuild_table_widget()
        self.cargar_productos()

    def _build_topbar(self):
        return ft.Container(
            content=ft.Row([ft.ElevatedButton("⬅ Volver", on_click=lambda e: self.volver_atras(), style=self.btn_secondary),
                            ft.Container(width=12),
                            ft.Column([ft.Text("Productos — Panel", weight=ft.FontWeight.BOLD, size=20, color=self.TEXT_PRIMARY),
                                       ft.Text("Gestión de productos", size=12, color=self.TEXT_MUTED)], spacing=2),
                            ft.Container(expand=True)]),
            padding=ft.padding.symmetric(vertical=12, horizontal=18),
            bgcolor=self.SURFACE,
            border=ft.border.all(1, self.SEPARATOR),
            border_radius=8
        )

    def _build_left_panel(self):
        btn_add = ft.ElevatedButton("➕ Nuevo producto", on_click=lambda e: self.mostrar_formulario_agregar(), style=self.btn_primary, width=180)
        btn_refresh = ft.ElevatedButton("🔁 Refrescar", on_click=lambda e: self.cargar_productos(), style=self.btn_secondary, width=180)
        panel = ft.Container(
            content=ft.Column([ft.Text("Acciones rápidas", weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY),
                               ft.Text("Crear y refrescar productos", size=12, color=self.TEXT_MUTED),
                               ft.Divider(color=self.SEPARATOR),
                               btn_add, ft.Container(height=8), btn_refresh, ft.Container(expand=True)], spacing=10),
            padding=ft.padding.all(14),
            bgcolor=self.PAPER,
            border=ft.border.all(1, self.SEPARATOR),
            border_radius=8,
            width=260
        )
        return panel

    # -------------------
    # Metadatos y tabla (lógica original)
    # -------------------
    def _load_metadata(self):
        conn = self.conexion.conectar()
        if conn is None:
            print("❌ No hay conexión para cargar metadata")
            return
        try:
            cur = conn.cursor(dictionary=True)
            dbname = getattr(self.conexion, "database", None)
            if not dbname:
                dbname = conn.database if hasattr(conn, "database") else None
            cur.execute(
                "SELECT COLUMN_NAME, DATA_TYPE, COLUMN_KEY, EXTRA "
                "FROM INFORMATION_SCHEMA.COLUMNS "
                "WHERE TABLE_SCHEMA=%s AND TABLE_NAME=%s "
                "ORDER BY ORDINAL_POSITION",
                (dbname, "productos")
            )
            cols = cur.fetchall()
            self.columns = []
            self.pk_column = None
            for c in cols:
                item = {
                    "name": c["COLUMN_NAME"],
                    "type": c["DATA_TYPE"],
                    "is_pk": True if c["COLUMN_KEY"] == "PRI" else False,
                    "extra": c.get("EXTRA", "")
                }
                self.columns.append(item)
                if item["is_pk"] and self.pk_column is None:
                    self.pk_column = item["name"]
            if not self.columns:
                print(f"❌ La tabla 'productos' no tiene columnas (o no existe).")
            else:
                print(f">> Metadata cargada productos: {[c['name'] for c in self.columns]}, pk={self.pk_column}")
        except Exception as ex:
            print(f"❌ Error al leer metadata de productos: {ex}")
        finally:
            self.conexion.cerrar(conn)

    def _rebuild_table_widget(self):
        cols = []
        for c in self.columns:
            label = c["name"].replace("_", " ").capitalize()
            cols.append(ft.DataColumn(ft.Text(label, color=self.TEXT_PRIMARY)))
        cols.append(ft.DataColumn(ft.Text("Acciones", color=self.TEXT_PRIMARY)))
        self.tabla = ft.DataTable(columns=cols, rows=[])
        try:
            if len(self.content.controls) >= 3:
                # reemplazar main area container
                self.main_area.content = self.tabla
            else:
                self.main_area.content = self.tabla
            self.page.update()
        except Exception:
            pass

    def cargar_productos(self):
        print(">> cargar_productos() llamado")
        if not getattr(self, "columns", []):
            print("❌ No hay metadata de columnas, no se cargan datos.")
            return
        # reconstruir filas
        self.tabla.rows.clear()
        conn = self.conexion.conectar()
        try:
            if conn is None:
                print("❌ No hay conexión a la base de datos")
                return
            cur = conn.cursor()
            cols_sql = ", ".join([f"`{c['name']}`" for c in self.columns])
            cur.execute(f"SELECT {cols_sql} FROM `productos`")
            filas = cur.fetchall()
            for row in filas:
                pk_val = row[0]
                btn_editar = ft.IconButton(icon=ft.Icons.EDIT, tooltip="Editar", on_click=lambda e, _id=pk_val: self.mostrar_formulario_editar_id(_id), icon_color=self.ACCENT)
                btn_borrar = ft.IconButton(icon=ft.Icons.DELETE, tooltip="Eliminar", icon_color="#EF4444", on_click=lambda e, _id=pk_val: self.confirmar_eliminar_id(_id))
                cells = [ft.DataCell(ft.Text(str(v) if v is not None else "", color=self.TEXT_PRIMARY)) for v in row]
                cells.append(ft.DataCell(ft.Row([btn_editar, btn_borrar], spacing=6)))
                self.tabla.rows.append(ft.DataRow(cells=cells))
            print(f">> {len(filas)} registros añadidos")
        except Exception as ex:
            print(f"❌ Error al cargar productos: {ex}")
        finally:
            self.conexion.cerrar(conn)
        try:
            self.page.update()
        except Exception:
            pass

    # ---- agregar / editar / eliminar (dinámicos) ----
    def mostrar_formulario_agregar(self, e=None):
        print(">> mostrar_formulario_agregar() (dinámico)")
        input_text_style = ft.TextStyle(color="white")
        label_style = ft.TextStyle(color=self.TEXT_MUTED)

        id_field = None
        if getattr(self, "pk_column", None):
            id_field = ft.TextField(label=f"{self.pk_column} (opcional)", hint_text="Dejar vacío para autoincrement", width=240, text_style=input_text_style, label_style=label_style)

        fields = []
        for c in self.columns:
            if c["is_pk"]:
                continue
            tf = ft.TextField(label=c["name"].replace("_", " ").capitalize(), text_style=input_text_style, label_style=label_style)
            fields.append((c["name"], tf))

        def guardar(ev):
            id_val = (id_field.value or "").strip() if id_field else ""
            conn = self.conexion.conectar()
            if conn is None:
                print("❌ No hay conexión al guardar")
                return
            try:
                cur = conn.cursor()
                if id_val:
                    try:
                        id_int = int(id_val)
                    except ValueError:
                        print("❌ ID inválido (no entero)")
                        return
                    cols = [self.pk_column] + [db for db, _ in fields]
                    placeholders = ", ".join(["%s"] * len(cols))
                    sql = f"INSERT INTO `productos` ({', '.join(['`'+c+'`' for c in cols])}) VALUES ({placeholders})"
                    params = (id_int,) + tuple(f.value for _, f in fields)
                else:
                    cols = [db for db, _ in fields]
                    placeholders = ", ".join(["%s"] * len(cols))
                    sql = f"INSERT INTO `productos` ({', '.join(['`'+c+'`' for c in cols])}) VALUES ({placeholders})"
                    params = tuple(f.value for _, f in fields)
                cur.execute(sql, params)
                conn.commit()
                print(">> Registro insertado correctamente (dinámico)")
                self._rebuild_table_widget()
                self.cargar_productos()
            except mysql.connector.IntegrityError as ie:
                print(f"❌ Integridad DB: {ie}")
            except Exception as ex:
                print(f"❌ Error al insertar: {ex}")
            finally:
                self.conexion.cerrar(conn)

        btn_save = ft.ElevatedButton("Guardar", on_click=guardar)
        btn_cancel = ft.ElevatedButton("Cancelar", on_click=lambda e: (self._rebuild_table_widget(), self.cargar_productos()))
        controls = []
        if id_field:
            controls.append(id_field)
        controls += [tf for _, tf in fields]
        form = ft.Column([ft.Text("➕ Nuevo Producto", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY)] + controls + [ft.Row([btn_cancel, btn_save], spacing=10)], spacing=10)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[ft.Container(content=form, padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)])
        try:
            self.page.update()
        except Exception:
            pass

    def mostrar_formulario_editar_id(self, pk_val):
        print(f">> mostrar_formulario_editar_id({pk_val}) (dinámico)")
        conn = self.conexion.conectar()
        if conn is None:
            print("❌ No hay conexión para editar")
            return
        try:
            cur = conn.cursor()
            cols = [c["name"] for c in self.columns]
            cur.execute(f"SELECT {', '.join(['`'+c+'`' for c in cols])} FROM `productos` WHERE `{self.pk_column}`=%s", (pk_val,))
            fila = cur.fetchone()
            if not fila:
                print("❌ Registro no encontrado")
                self._rebuild_table_widget()
                return
            fields = []
            controls = []
            for i, c in enumerate(self.columns):
                if c["is_pk"]:
                    continue
                val = fila[i]
                tf = ft.TextField(label=c["name"].replace("_", " ").capitalize(), value=str(val) if val is not None else "", text_style=ft.TextStyle(color="white"), label_style=ft.TextStyle(color=self.TEXT_MUTED))
                fields.append((c["name"], tf))
                controls.append(tf)
        except Exception as ex:
            print(f"❌ Error al cargar registro para editar: {ex}")
            return
        finally:
            self.conexion.cerrar(conn)

        def guardar(ev):
            conn2 = self.conexion.conectar()
            if conn2 is None:
                print("❌ No hay conexión al guardar edición")
                return
            try:
                cur2 = conn2.cursor()
                set_expr = ", ".join([f"`{db}`=%s" for db, _ in fields])
                sql = f"UPDATE `productos` SET {set_expr} WHERE `{self.pk_column}`=%s"
                params = tuple(f.value for _, f in fields) + (pk_val,)
                cur2.execute(sql, params)
                conn2.commit()
                print(">> Registro actualizado correctamente (dinámico)")
                self._rebuild_table_widget()
                self.cargar_productos()
            except Exception as ex:
                print(f"❌ Error al actualizar: {ex}")
            finally:
                self.conexion.cerrar(conn2)

        btn_save = ft.ElevatedButton("Guardar", on_click=guardar)
        btn_cancel = ft.ElevatedButton("Cancelar", on_click=lambda e: (self._rebuild_table_widget(), self.cargar_productos()))
        form = ft.Column([ft.Text(f"✏️ Editar (ID: {pk_val})", size=18, weight=ft.FontWeight.BOLD, color=self.TEXT_PRIMARY)] + controls + [ft.Row([btn_cancel, btn_save], spacing=10)], spacing=10)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[ft.Container(content=form, padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)])
        try:
            self.page.update()
        except Exception:
            pass

    def confirmar_eliminar_id(self, pk_val):
        print(f">> confirmar_eliminar_id({pk_val}) (dinámico)")
        def eliminar(ev):
            conn = self.conexion.conectar()
            try:
                if conn is None:
                    print("❌ No hay conexión al eliminar")
                    return
                cur = conn.cursor()
                cur.execute(f"DELETE FROM `productos` WHERE `{self.pk_column}`=%s", (pk_val,))
                conn.commit()
                print(">> Registro eliminado correctamente (dinámico)")
                self._rebuild_table_widget()
                self.cargar_productos()
            except Exception as ex:
                print(f"❌ Error al eliminar: {ex}")
            finally:
                self.conexion.cerrar(conn)
        btn_yes = ft.ElevatedButton("Eliminar", on_click=eliminar, style=ft.ButtonStyle(bgcolor="#EF4444", color="white"))
        btn_cancel = ft.ElevatedButton("Cancelar", on_click=lambda e: (self._rebuild_table_widget(), self.cargar_productos()))
        confirm = ft.Container([ft.Text("⚠️ Confirmar eliminación", color=self.TEXT_PRIMARY), ft.Text(f"¿Eliminar ID: {pk_val}?", color=self.TEXT_MUTED), ft.Row([btn_cancel, btn_yes], spacing=10)], padding=ft.padding.all(16), bgcolor=self.SURFACE, border=ft.border.all(1, self.SEPARATOR), border_radius=8)
        self.main_area.content = ft.ListView(expand=True, padding=ft.padding.all(8), spacing=10, controls=[confirm])
        try:
            self.page.update()
        except Exception:
            pass