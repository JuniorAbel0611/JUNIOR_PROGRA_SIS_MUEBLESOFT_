"""
Utilidades y funciones auxiliares
"""
import hashlib
import re
from datetime import datetime
from typing import Optional, Tuple

def hash_password(password: str) -> str:
    """Genera un hash SHA-256 de la contraseña"""
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password: str, hashed: str) -> bool:
    """Verifica si la contraseña coincide con el hash"""
    return hash_password(password) == hashed

def validate_email(email: str) -> bool:
    """Valida formato de email"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_dni(dni: str) -> bool:
    """Valida formato de DNI (8 dígitos)"""
    return dni.isdigit() and len(dni) == 8

def validate_phone(phone: str) -> bool:
    """Valida formato de teléfono"""
    # Acepta números con o sin guiones/espacios
    cleaned = re.sub(r'[\s-]', '', phone)
    return cleaned.isdigit() and len(cleaned) >= 9

def format_currency(amount: float) -> str:
    """Formatea un número como moneda"""
    return f"${amount:,.2f}"

def format_date(date_str: str) -> str:
    """Formatea una fecha para mostrar"""
    try:
        if isinstance(date_str, str):
            # Intentar diferentes formatos
            for fmt in ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d"]:
                try:
                    dt = datetime.strptime(date_str, fmt)
                    return dt.strftime("%d/%m/%Y %H:%M")
                except:
                    continue
        return str(date_str)
    except:
        return str(date_str)

def get_current_datetime() -> str:
    """Obtiene la fecha y hora actual en formato MySQL"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def truncate_text(text: str, max_length: int = 50) -> str:
    """Trunca texto si es muy largo"""
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."

def validate_required(value: Optional[str], field_name: str) -> Tuple[bool, str]:
    """Valida que un campo requerido no esté vacío"""
    if not value or not value.strip():
        return False, f"{field_name} es requerido"
    return True, ""

def validate_number(value: str, field_name: str, min_val: Optional[float] = None, max_val: Optional[float] = None) -> Tuple[bool, str]:
    """Valida que un valor sea numérico y esté en rango"""
    try:
        num = float(value)
        if min_val is not None and num < min_val:
            return False, f"{field_name} debe ser mayor o igual a {min_val}"
        if max_val is not None and num > max_val:
            return False, f"{field_name} debe ser menor o igual a {max_val}"
        return True, ""
    except ValueError:
        return False, f"{field_name} debe ser un número válido"

